# 🎬 Rapport de test CineaMatch

**Date :** 11/05/2026 21:24:11
**Site :** https://cineamatch.com
**Profils testés :** 10
**Score moyen :** 10.0/10
**Problèmes détectés :** 0

---

## Récapitulatif

| Profil | Score | Films | Problèmes | Durée |
|--------|-------|-------|-----------|-------|
| 🟢 💕 Romance mature émouvante mais pas triste | 10/10 | Crazy, Stupid, Love / The Holiday / Il était Temps | ✅ 0 | 118.6s |
| 🟢 🚀 SF familiale feel-good | 10/10 | Ultraman: Rising / Scooby-Doo et Krypto ! / Transformers : Le Commencement | ✅ 0 | 124.0s |
| 🟢 😱 Horreur psychologique sans gore | 10/10 | Hérédité / The Witch / Sans un bruit | ✅ 0 | 127.9s |
| 🟢 🕵️ Thriller intelligent mais pas lent | 10/10 | Shutter Island / La Planète des singes : L'Affrontement / La Fille du train | ✅ 0 | 119.0s |
| 🟢 🇫🇷 Comédie française entre amis | 10/10 | Astérix & Obélix : Mission Cléopâtre / Nos jours heureux / Bienvenue à Marly-Gomont | ✅ 0 | 111.0s |
| 🟢 💑 Romance sans références — fallback couple | 10/10 | Minuit à Paris / Always Be My Maybe / 30 ans sinon rien | ✅ 0 | 112.2s |
| 🟢 🏆 Biopic inspirant dépassement humain | 10/10 | Imitation game / Presque Célèbre / Boy Erased | ✅ 0 | 123.3s |
| 🟢 🇰🇷 Thriller coréen style Parasite | 10/10 | Old Boy / Memories of Murder / J'ai rencontré le Diable | ✅ 0 | 116.9s |
| 🟢 🎌 Animé feel-good entre amis | 10/10 | My Hero Academia : Heroes Rising / My Hero Academia : Two Heroes / One Piece Film - Stampede | ✅ 0 | 125.6s |
| 🟢 ⚡ Action récente 2020+ solo | 10/10 | John Wick : Chapitre 4 / Mission : Impossible - Dead Reckoning Partie 1 / Nobody | ✅ 0 | 120.6s |

---

## 1. 💕 Romance mature émouvante mais pas triste

### 📋 Questionnaire

| Question | Réponse |
|----------|---------|
| Contexte | En couple |
| Mood | Émouvant / Inspirant |
| Langue | 🇺🇸 Américain |
| Durée | Long (>2h) |
| Exclusions | Trop triste, Trop lent, Films d'ados |
| Époque | Moderne (2000-2020) |
| Références | La La Land, Her |

### 🎥 Films recommandés

#### #1 Match — Crazy, Stupid, Love

- **Compatibilité :** 🔥 95% de compatibilité
- **Genres :** Comédie, Drame, Romance
- **Année :** 2011
- **Note TMDB :** ⭐ 7.3
- **Explication IA :** "Dans la lignée de 'Crazy Stupid Love', ce film mêle humour et romance avec des personnages attachants, parfait pour une soirée chaleureuse en couple."

#### #2 Match — The Holiday

- **Compatibilité :** 🔥 88% de compatibilité
- **Genres :** Comédie, Romance
- **Année :** 2006
- **Note TMDB :** ⭐ 7.1
- **Explication IA :** "'The Holiday' offre une romance réconfortante et des échanges culturels, idéal pour se blottir et discuter des relations amoureuses."

#### #3 Match — Il était Temps

- **Compatibilité :** 🔥 80% de compatibilité
- **Genres :** Drame, Romance, Fantastique
- **Année :** 2013
- **Note TMDB :** ⭐ 7.9
- **Explication IA :** "'Il était Temps' combine romance et voyage dans le temps, créant une atmosphère douce et émotive, à l'image de 'La La Land'."

> ⚠️ **Bannière conflit détectée :** 💡 Ton humeur et une de tes exclusions se chevauchaient légèrement. L'humeur a été prioritaire — tes exclusions restent appliquées au maximum.

### 🔍 Analyse critique

**Score global : 🟢 10/10**

**Durée du test :** 118.6s

**✅ Points cohérents :**
- #1 "Crazy, Stupid, Love" — ✓ contient "romance"
- #1 "Crazy, Stupid, Love" — ✓ contient "couple"
- #2 "The Holiday" — ✓ contient "romance"
- #2 "The Holiday" — ✓ contient "amour"
- #3 "Il était Temps" — ✓ contient "romance"

**✅ Aucun problème détecté**

---

## 2. 🚀 SF familiale feel-good

### 📋 Questionnaire

| Question | Réponse |
|----------|---------|
| Contexte | En famille |
| Mood | SF / Mystère |
| Langue | 🇺🇸 Américain |
| Durée | Court (<1h45) |
| Exclusions | Trop complexe, Trop violent, Contenu adulte |
| Époque | Récent (2020+) |
| Références | WALL-E, Big Hero 6 |

### 🎥 Films recommandés

#### #1 Match — Ultraman: Rising

- **Compatibilité :** 🔥 95% de compatibilité
- **Genres :** Animation, Science-Fiction, Familial
- **Année :** 2024
- **Note TMDB :** ⭐ 8.0
- **Explication IA :** "Dans la lignée de 'Les Nouveaux Héros', 'Ultraman: Rising' offre une aventure héroïque pleine d'action et de mystère, idéale pour toute la famille."

#### #2 Match — Scooby-Doo et Krypto !

- **Compatibilité :** 🔥 88% de compatibilité
- **Genres :** Animation, Familial, Mystère
- **Année :** 2023
- **Note TMDB :** ⭐ 7.4
- **Explication IA :** "Avec 'Scooby-Doo et Krypto !', plonge dans un mystère amusant où l'humour et l'aventure se mêlent, parfait pour les fans de Scooby-Doo."

#### #3 Match — Transformers : Le Commencement

- **Compatibilité :** 🔥 80% de compatibilité
- **Genres :** Animation, Science-Fiction, Aventure
- **Année :** 2024
- **Note TMDB :** ⭐ 8.0
- **Explication IA :** "'Transformers : Le Commencement' explore les origines d'Optimus Prime, alliant action et science-fiction, tout en captivant les jeunes spectateurs."

### 🔍 Analyse critique

**Score global : 🟢 10/10**

**Durée du test :** 124.0s

**✅ Points cohérents :**
- #1 "Ultraman: Rising" — ✓ contient "famille"
- #1 "Ultraman: Rising" — ✓ contient "aventure"
- #2 "Scooby-Doo et Krypto !" — ✓ contient "aventure"
- #3 "Transformers : Le Commencement" — ✓ contient "aventure"

**✅ Aucun problème détecté**

---

## 3. 😱 Horreur psychologique sans gore

### 📋 Questionnaire

| Question | Réponse |
|----------|---------|
| Contexte | Seul |
| Mood | Horreur |
| Langue | 🇺🇸 Américain |
| Durée | Long (>2h) |
| Exclusions | Trop violent |
| Époque | Moderne (2000-2020) |
| Références | Hereditary, The Others |

### 🎥 Films recommandés

#### #1 Match — Hérédité

- **Compatibilité :** 🔥 87% de compatibilité
- **Genres :** Horreur, Mystère, Thriller
- **Année :** 2018
- **Note TMDB :** ⭐ 7.3
- **Explication IA :** "Dans la lignée de 'Cursed: The True Nature of Hereditary', 'Hérédité' explore les secrets familiaux avec une intensité troublante."

#### #2 Match — The Witch

- **Compatibilité :** 🔥 75% de compatibilité
- **Genres :** Horreur
- **Année :** 2016
- **Note TMDB :** ⭐ 7.0
- **Explication IA :** "L'atmosphère oppressante de 'The Witch' rappelle le style de 'The Others', avec une tension psychologique palpable."

#### #3 Match — Sans un bruit

- **Compatibilité :** 🔥 72% de compatibilité
- **Genres :** Horreur, Drame, Science-Fiction
- **Année :** 2018
- **Note TMDB :** ⭐ 7.4
- **Explication IA :** "Si tu cherches une expérience immersive, 'Sans un bruit' offre une tension constante, tout en jouant sur le silence comme un personnage."

> ⚠️ **Bannière conflit détectée :** 💡 Ton humeur et une de tes exclusions se chevauchaient légèrement. L'humeur a été prioritaire — tes exclusions restent appliquées au maximum.

### 🔍 Analyse critique

**Score global : 🟢 10/10**

**Durée du test :** 127.9s

**✅ Points cohérents :**
- #2 "The Witch" — ✓ contient "atmosphère"
- #2 "The Witch" — ✓ contient "psychologique"
- #2 "The Witch" — ✓ contient "tension"
- #3 "Sans un bruit" — ✓ contient "tension"

**✅ Aucun problème détecté**

---

## 4. 🕵️ Thriller intelligent mais pas lent

### 📋 Questionnaire

| Question | Réponse |
|----------|---------|
| Contexte | Seul |
| Mood | Thriller |
| Langue | 🇺🇸 Américain |
| Durée | Long (>2h) |
| Exclusions | Trop lent, Trop complexe |
| Époque | Moderne (2000-2020) |
| Références | Gone Girl, Knives Out |

### 🎥 Films recommandés

#### #1 Match — Shutter Island

- **Compatibilité :** 🔥 95% de compatibilité
- **Genres :** Drame, Thriller, Mystère
- **Année :** 2010
- **Note TMDB :** ⭐ 8.2
- **Explication IA :** "Dans la lignée de 'Gone Girl', 'Shutter Island' offre un suspense haletant et une intrigue psychologique captivante."

#### #2 Match — La Planète des singes : L'Affrontement

- **Compatibilité :** 🔥 87% de compatibilité
- **Genres :** Science-Fiction, Action, Drame
- **Année :** 2014
- **Note TMDB :** ⭐ 7.3
- **Explication IA :** "'La Planète des singes : L'Affrontement' allie drame et tension, tout en explorant des thèmes de survie et de conflit, idéal pour un moment intense."

#### #3 Match — La Fille du train

- **Compatibilité :** 🔥 80% de compatibilité
- **Genres :** Crime, Mystère, Thriller
- **Année :** 2016
- **Note TMDB :** ⭐ 6.4
- **Explication IA :** "'La Fille du train' propose un mystère intrigant avec une héroïne complexe, parfait pour ceux qui ont aimé le suspense de 'Gone Girl'."

### 🔍 Analyse critique

**Score global : 🟢 10/10**

**Durée du test :** 119.0s

**✅ Points cohérents :**
- #1 "Shutter Island" — ✓ contient "suspense"
- #2 "La Planète des singes : L'Affrontement" — ✓ contient "tension"
- #3 "La Fille du train" — ✓ contient "suspense"

**✅ Aucun problème détecté**

---

## 5. 🇫🇷 Comédie française entre amis

### 📋 Questionnaire

| Question | Réponse |
|----------|---------|
| Contexte | Entre amis |
| Mood | Rire / Comédie |
| Langue | 🇫🇷 Français |
| Durée | Court (<1h45) |
| Exclusions | Trop triste, Contenu adulte |
| Époque | Moderne (2000-2020) |
| Références | (aucune) |

### 🎥 Films recommandés

#### #1 Match — Astérix & Obélix : Mission Cléopâtre

- **Compatibilité :** 🔥 95% de compatibilité
- **Genres :** Familial, Fantastique, Comédie
- **Année :** 2002
- **Note TMDB :** ⭐ 7.4
- **Explication IA :** "Dans la lignée des comédies populaires, 'Astérix & Obélix : Mission Cléopâtre' offre un humour décalé et des personnages mémorables, parfait pour rire entre amis."

#### #2 Match — Nos jours heureux

- **Compatibilité :** 🔥 88% de compatibilité
- **Genres :** Comédie, Familial
- **Année :** 2006
- **Note TMDB :** ⭐ 7.3
- **Explication IA :** "'Nos jours heureux' capture l'esprit des colonies de vacances avec des situations cocasses et des personnages attachants, idéal pour une soirée entre amis."

#### #3 Match — Bienvenue à Marly-Gomont

- **Compatibilité :** 🔥 80% de compatibilité
- **Genres :** Comédie
- **Année :** 2016
- **Note TMDB :** ⭐ 6.8
- **Explication IA :** "Avec 'Bienvenue à Marly-Gomont', plonge dans une comédie touchante sur l'intégration, pleine de rires et de chaleur, qui résonnera avec ton envie de rire en groupe."

### 🔍 Analyse critique

**Score global : 🟢 10/10**

**Durée du test :** 111.0s

**✅ Points cohérents :**
- #1 "Astérix & Obélix : Mission Cléopâtre" — ✓ contient "humour"
- #1 "Astérix & Obélix : Mission Cléopâtre" — ✓ contient "comédie"
- #1 "Astérix & Obélix : Mission Cléopâtre" — ✓ contient "rire"
- #2 "Nos jours heureux" — ✓ contient "comédie"
- #3 "Bienvenue à Marly-Gomont" — ✓ contient "comédie"
- #3 "Bienvenue à Marly-Gomont" — ✓ contient "rire"

**✅ Aucun problème détecté**

---

## 6. 💑 Romance sans références — fallback couple

### 📋 Questionnaire

| Question | Réponse |
|----------|---------|
| Contexte | En couple |
| Mood | Émouvant / Inspirant |
| Langue | 🇺🇸 Américain |
| Durée | Court (<1h45) |
| Exclusions | Trop triste, Films d'ados |
| Époque | Moderne (2000-2020) |
| Références | (aucune) |

### 🎥 Films recommandés

#### #1 Match — Minuit à Paris

- **Compatibilité :** 🔥 95% de compatibilité
- **Genres :** Fantastique, Comédie, Romance
- **Année :** 2011
- **Note TMDB :** ⭐ 7.5
- **Explication IA :** "Dans la lignée de 'La La Land', 'Minuit à Paris' tisse une romance magique à Paris, pleine de nostalgie et d'émerveillement."

#### #2 Match — Always Be My Maybe

- **Compatibilité :** 🔥 88% de compatibilité
- **Genres :** Romance, Comédie
- **Année :** 2019
- **Note TMDB :** ⭐ 6.6
- **Explication IA :** "'Always Be My Maybe' explore une belle histoire d'amour retrouvée, parfaite pour une soirée réconfortante en couple."

#### #3 Match — 30 ans sinon rien

- **Compatibilité :** 🔥 80% de compatibilité
- **Genres :** Comédie, Fantastique, Romance
- **Année :** 2004
- **Note TMDB :** ⭐ 6.8
- **Explication IA :** "'30 ans sinon rien' mélange humour et romance avec une touche de magie, idéal pour une soirée légère et émouvante."

> ⚠️ **Bannière conflit détectée :** 💡 Ton humeur et une de tes exclusions se chevauchaient légèrement. L'humeur a été prioritaire — tes exclusions restent appliquées au maximum.

### 🔍 Analyse critique

**Score global : 🟢 10/10**

**Durée du test :** 112.2s

**✅ Points cohérents :**
- #1 "Minuit à Paris" — ✓ contient "romance"
- #2 "Always Be My Maybe" — ✓ contient "romance"
- #2 "Always Be My Maybe" — ✓ contient "amour"
- #2 "Always Be My Maybe" — ✓ contient "couple"
- #3 "30 ans sinon rien" — ✓ contient "romance"

**✅ Aucun problème détecté**

---

## 7. 🏆 Biopic inspirant dépassement humain

### 📋 Questionnaire

| Question | Réponse |
|----------|---------|
| Contexte | Seul |
| Mood | Émouvant / Inspirant |
| Langue | 🇺🇸 Américain |
| Durée | Long (>2h) |
| Exclusions | Trop lent |
| Époque | Moderne (2000-2020) |
| Références | Whiplash, Bohemian Rhapsody |

### 🎥 Films recommandés

#### #1 Match — Imitation game

- **Compatibilité :** 🔥 95% de compatibilité
- **Genres :** Histoire, Drame, Thriller
- **Année :** 2014
- **Note TMDB :** ⭐ 8.0
- **Explication IA :** "Dans la lignée de 'Bohemian Rhapsody', 'Imitation Game' explore la vie d'un génie incompris, avec une intensité émotionnelle captivante."

#### #2 Match — Presque Célèbre

- **Compatibilité :** 🔥 88% de compatibilité
- **Genres :** Drame, Musique
- **Année :** 2000
- **Note TMDB :** ⭐ 7.5
- **Explication IA :** "'Presque Célèbre' évoque la passion musicale et la quête d'identité, tout comme 'Whiplash', avec une touche nostalgique."

#### #3 Match — Boy Erased

- **Compatibilité :** 🔥 80% de compatibilité
- **Genres :** Drame
- **Année :** 2018
- **Note TMDB :** ⭐ 7.0
- **Explication IA :** "'Boy Erased' aborde le thème du dépassement personnel face à l'adversité, résonnant avec l'esprit de 'Whiplash'."

### 🔍 Analyse critique

**Score global : 🟢 10/10**

**Durée du test :** 123.3s

**✅ Points cohérents :**
- #3 "Boy Erased" — ✓ contient "dépassement"

**✅ Aucun problème détecté**

---

## 8. 🇰🇷 Thriller coréen style Parasite

### 📋 Questionnaire

| Question | Réponse |
|----------|---------|
| Contexte | Seul |
| Mood | Thriller |
| Langue | 🌏 Asiatique |
| Durée | Long (>2h) |
| Exclusions | Trop lent |
| Époque | Moderne (2000-2020) |
| Références | Parasite, Oldboy |

### 🎥 Films recommandés

#### #1 Match — Old Boy

- **Compatibilité :** 🔥 95% de compatibilité
- **Genres :** Drame, Thriller, Mystère
- **Année :** 2003
- **Note TMDB :** ⭐ 8.2
- **Explication IA :** "Dans la lignée de 'Oldboy', ce thriller captivant explore la vengeance avec une intensité psychologique saisissante."

#### #2 Match — Memories of Murder

- **Compatibilité :** 🔥 92% de compatibilité
- **Genres :** Crime, Drame, Thriller
- **Année :** 2003
- **Note TMDB :** ⭐ 8.1
- **Explication IA :** "'Memories of Murder' offre une enquête poignante sur des meurtres non résolus, avec la même tension sociale que 'Parasite'."

#### #3 Match — J'ai rencontré le Diable

- **Compatibilité :** 🔥 80% de compatibilité
- **Genres :** Thriller, Horreur
- **Année :** 2010
- **Note TMDB :** ⭐ 7.8
- **Explication IA :** "'J'ai rencontré le Diable' est un thriller brutal et psychologique, parfait pour ceux qui recherchent une expérience intense et sombre."

### 🔍 Analyse critique

**Score global : 🟢 10/10**

**Durée du test :** 116.9s

**✅ Points cohérents :**
- #2 "Memories of Murder" — ✓ contient "tension"
- #2 "Memories of Murder" — ✓ contient "social"
- #3 "J'ai rencontré le Diable" — ✓ contient "intense"

**✅ Aucun problème détecté**

---

## 9. 🎌 Animé feel-good entre amis

### 📋 Questionnaire

| Question | Réponse |
|----------|---------|
| Contexte | Entre amis |
| Mood | Action / Aventure |
| Langue | 🌏 Asiatique |
| Durée | Court (<1h45) |
| Exclusions | Trop triste, Trop complexe |
| Époque | Moderne (2000-2020) |
| Références | Spirited Away, Your Name |

### 🎥 Films recommandés

#### #1 Match — My Hero Academia : Heroes Rising

- **Compatibilité :** 🔥 95% de compatibilité
- **Genres :** Animation, Action, Fantastique
- **Année :** 2019
- **Note TMDB :** ⭐ 8.1
- **Explication IA :** "Dans la lignée de 'Your Name.', 'My Hero Academia: Heroes Rising' offre une aventure épique et émotive, parfaite pour une soirée entre amis."

#### #2 Match — My Hero Academia : Two Heroes

- **Compatibilité :** 🔥 88% de compatibilité
- **Genres :** Animation, Action, Aventure
- **Année :** 2018
- **Note TMDB :** ⭐ 7.9
- **Explication IA :** "'My Hero Academia: Two Heroes' combine action et camaraderie, tout en gardant un rythme entraînant, idéal pour partager des rires avec des amis."

#### #3 Match — One Piece Film - Stampede

- **Compatibilité :** 🔥 80% de compatibilité
- **Genres :** Animation, Action, Aventure
- **Année :** 2019
- **Note TMDB :** ⭐ 7.8
- **Explication IA :** "'One Piece Film - Stampede' promet une aventure palpitante avec des personnages attachants, dans la veine de l'esthétique vibrante de 'Your Name.'"

### 🔍 Analyse critique

**Score global : 🟢 10/10**

**Durée du test :** 125.6s

**✅ Points cohérents :**
- #1 "My Hero Academia : Heroes Rising" — ✓ contient "animation"
- #1 "My Hero Academia : Heroes Rising" — ✓ contient "aventure"
- #2 "My Hero Academia : Two Heroes" — ✓ contient "animation"
- #2 "My Hero Academia : Two Heroes" — ✓ contient "aventure"
- #3 "One Piece Film - Stampede" — ✓ contient "animation"
- #3 "One Piece Film - Stampede" — ✓ contient "aventure"

**✅ Aucun problème détecté**

---

## 10. ⚡ Action récente 2020+ solo

### 📋 Questionnaire

| Question | Réponse |
|----------|---------|
| Contexte | Seul |
| Mood | Action / Aventure |
| Langue | 🇺🇸 Américain |
| Durée | Long (>2h) |
| Exclusions | Trop lent, Trop complexe |
| Époque | Récent (2020+) |
| Références | John Wick, Mission: Impossible |

### 🎥 Films recommandés

#### #1 Match — John Wick : Chapitre 4

- **Compatibilité :** 🔥 95% de compatibilité
- **Genres :** Action, Thriller, Crime
- **Année :** 2023
- **Note TMDB :** ⭐ 7.7
- **Explication IA :** "Dans la lignée de 'John Wick', ce chapitre 4 intensifie l'action avec des combats épiques et une esthétique visuelle saisissante."

#### #2 Match — Mission : Impossible - Dead Reckoning Partie 1

- **Compatibilité :** 🔥 83% de compatibilité
- **Genres :** Action, Thriller, Aventure
- **Année :** 2023
- **Note TMDB :** ⭐ 7.5
- **Explication IA :** "'Mission : Impossible - Dead Reckoning' offre une aventure palpitante, avec des cascades audacieuses et un suspense à couper le souffle, idéal pour les fans d'action."

#### #3 Match — Nobody

- **Compatibilité :** 🔥 80% de compatibilité
- **Genres :** Action, Thriller
- **Année :** 2021
- **Note TMDB :** ⭐ 7.9
- **Explication IA :** "'Nobody' réinvente le thriller d'action avec un protagoniste inattendu, mêlant humour noir et séquences d'action percutantes, parfait pour une immersion solo."

### 🔍 Analyse critique

**Score global : 🟢 10/10**

**Durée du test :** 120.6s

**✅ Points cohérents :**
- #1 "John Wick : Chapitre 4" — ✓ contient "action"
- #2 "Mission : Impossible - Dead Reckoning Partie 1" — ✓ contient "action"
- #3 "Nobody" — ✓ contient "action"

**✅ Aucun problème détecté**

---

## 📊 Conclusion générale

**Profils bien gérés (≥8/10) :**
- ✅ 💕 Romance mature émouvante mais pas triste
- ✅ 🚀 SF familiale feel-good
- ✅ 😱 Horreur psychologique sans gore
- ✅ 🕵️ Thriller intelligent mais pas lent
- ✅ 🇫🇷 Comédie française entre amis
- ✅ 💑 Romance sans références — fallback couple
- ✅ 🏆 Biopic inspirant dépassement humain
- ✅ 🇰🇷 Thriller coréen style Parasite
- ✅ 🎌 Animé feel-good entre amis
- ✅ ⚡ Action récente 2020+ solo

_Rapport généré automatiquement par l'agent de test CineaMatch._
