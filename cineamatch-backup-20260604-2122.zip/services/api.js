// URL OpenAI : proxy Cloudflare Pages en production, direct en local
const OPENAI_URL = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
    ? 'https://api.openai.com/v1/chat/completions'
    : '/api/openai';

// Proxy TMDB : en production, toutes les requêtes passent par /api/tmdb (clé cachée côté serveur)
// En dev/localhost, requête directe avec la clé depuis le localStorage
const IS_PROD = window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1';

// Construit l'URL TMDB selon l'environnement
// En prod : /api/tmdb?path=/movie/123&language=fr-FR  (clé gérée par le Worker)
// En dev  : https://api.themoviedb.org/3/movie/123?api_key=XXX&language=fr-FR
export function tmdbUrl(path, params = {}) {
    if (IS_PROD) {
        const qs = new URLSearchParams({ path, ...params }).toString();
        return `/api/tmdb?${qs}`;
    } else {
        const qs = new URLSearchParams({ api_key: tmdbService.apiKey, ...params }).toString();
        return `https://api.themoviedb.org/3${path}?${qs}`;
    }
}

// Clé de fallback dev — à remplacer par une clé valide si la clé localStorage est vide
const _DEV_KEY = '';

export const tmdbService = {
    apiKey: '',
    lang: 'fr-FR',
    _detailsCache: new Map(), // Perf 15 : cache en mémoire pour getMovieDetails

    init(key) {
        this.apiKey = key;
    },

    setLanguage(lang) {
        this.lang = lang === 'en' ? 'en-US' : 'fr-FR';
    },

    // Vide le cache détails (à appeler au début de chaque nouvelle session)
    clearDetailsCache() {
        this._detailsCache.clear();
        console.log('🗑️ Cache détails TMDB vidé');
    },

    async searchMovies(query) {
        if (!this.apiKey || this.apiKey === 'MOCK') {
            console.warn("⚠️ TMDb API Key is missing. Returning MOCK search results.");
            return { 
                results: [
                    { id: 27205, title: 'Inception', release_date: '2010-07-16', poster_path: '/edv9riS99vS67itFvS49p9S90E.jpg' },
                    { id: 157336, title: 'Interstellar', release_date: '2014-11-05', poster_path: '/gEU2QniE6E77NI6lCU6MvrIdYjD.jpg' },
                    { id: 155, title: 'The Dark Knight', release_date: '2008-07-16', poster_path: '/qJ2tW6WMUDux911r6m7haRef0WH.jpg' }
                ] 
            };
        }
        const url = tmdbUrl('/search/movie', { query: encodeURIComponent(query), language: this.lang });
        const resp = await fetch(url);
        if (!resp.ok) {
            console.error(`❌ TMDb Search Error: ${resp.status} ${resp.statusText}`);
            return { results: [] };
        }
        return await resp.json();
    },

    async getRecommendations(movieIds) {
        const allSuggestions = await Promise.allSettled(movieIds.map(async id => {
            const url = tmdbUrl(`/movie/${id}/recommendations`, { language: this.lang });
            const resp = await fetch(url);
            if (!resp.ok) { console.warn(`TMDB reco ${id}: HTTP ${resp.status}`); return []; }
            const data = await resp.json();
            return data.results || [];
        }));
        const flat = [].concat(...allSuggestions.map(r => r.status === 'fulfilled' ? r.value : []));
        return Array.from(new Map(flat.map(item => [item.id, item])).values());
    },

    async getMovieDetails(movieId) {
        // Perf 15 : retourner depuis le cache si déjà récupéré dans cette session
        const cacheKey = `${movieId}_${this.lang}`;
        if (this._detailsCache.has(cacheKey)) {
            return this._detailsCache.get(cacheKey);
        }

        if (this.apiKey === 'MOCK' || !this.apiKey) {
            return {
                id: movieId,
                title: "Inception Test",
                release_date: "2010-07-16",
                genres: [{ id: 878, name: "SF" }, { id: 28, name: "Action" }],
                vote_average: 8.8,
                vote_count: 35000,
                poster_path: "/edv9riS99vS67itFvS49p9S90E.jpg",
                overview: "Un voleur qui utilise une technologie de partage de rêves pour extraire des secrets...",
                videos: { results: [] },
                'watch/providers': { results: { FR: { flatrate: [{ provider_id: 8, logo_path: "/t2yyOuvvBkUMXvUughv9zO9pob.jpg", provider_name: "Netflix" }] } } },
                release_dates: { results: [{ iso_3166_1: "FR", release_dates: [{ certification: "12" }] }] }
            };
        }
        const url = tmdbUrl(`/movie/${movieId}`, { append_to_response: 'videos,watch/providers,release_dates,credits', language: this.lang });
        const resp = await fetch(url);
        if (!resp.ok) {
            console.error(`❌ TMDb getMovieDetails Error: ${resp.status} ${resp.statusText} (movieId: ${movieId})`);
            return null;
        }
        const data = await resp.json();

        // TMDb filtre les vidéos par langue → presque aucune bande-annonce en fr-FR
        // Si aucune vidéo trouvée, on refait la requête sans langue pour récupérer les trailers YouTube
        if (!data.videos?.results?.length) {
            try {
                const videoResp = await fetch(
                    tmdbUrl(`/movie/${movieId}/videos`)
                );
                if (videoResp.ok) {
                    const videoData = await videoResp.json();
                    data.videos = videoData;
                }
            } catch(e) { /* silencieux */ }
        }

        // Mettre en cache pour les appels suivants (reroll, rescue pass, etc.)
        this._detailsCache.set(cacheKey, data);
        return data;
    },

    async searchActor(actorName) {
        if (!this.apiKey || this.apiKey === 'MOCK') return 287; // Brad Pitt Mock ID
        const url = tmdbUrl('/search/person', { query: encodeURIComponent(actorName), language: this.lang });
        const resp = await fetch(url);
        if (!resp.ok) { console.warn(`searchActor HTTP ${resp.status}`); return null; }
        const data = await resp.json();
        if (data.results && data.results.length > 0) {
            console.log(`🎬 Found actor: ${data.results[0].name} (ID: ${data.results[0].id})`);
            return data.results[0].id;
        }
        return null;
    },

    async getActorMovies(actorId) {
        const url = tmdbUrl(`/person/${actorId}/movie_credits`, { language: this.lang });
        const resp = await fetch(url);
        if (!resp.ok) { console.warn(`getActorMovies HTTP ${resp.status}`); return []; }
        const data = await resp.json();
        return data.cast || [];
    },

    async getMovieTopCast(movieId) {
        if (!this.apiKey || this.apiKey === 'MOCK') return [];
        try {
            const url = tmdbUrl(`/movie/${movieId}/credits`);
            const resp = await fetch(url);
            if (!resp.ok) return [];
            const data = await resp.json();
            // Retourne les IDs des 3 premiers acteurs (têtes d'affiche)
            return (data.cast || []).slice(0, 3).map(a => a.id);
        } catch (e) { return []; }
    },

    // Enrichit les N meilleurs candidats avec cast + réalisateur pour le scorer IA
    // Appels /credits en parallèle sur les topN films les mieux notés (qualité pondérée)
    async enrichCandidatesWithCast(candidates, topN = 15) {
        if (!this.apiKey || this.apiKey === 'MOCK' || candidates.length === 0) return candidates;
        // Trier par score qualité pondéré : vote_average × log10(vote_count+1)
        const scored = candidates.map(c => ({
            c,
            q: (c.vote_average || 0) * Math.log10((c.vote_count || 1) + 1)
        }));
        scored.sort((a, b) => b.q - a.q);
        const topIds = scored.slice(0, topN).map(s => s.c.id);

        // Fetch crédits en parallèle (15 appels ~100ms chacun = 150ms total)
        const results = await Promise.allSettled(
            topIds.map(id => this.getMovieCastAndCrew(id))
        );

        // Map id → crédits
        const creditMap = {};
        topIds.forEach((id, i) => {
            if (results[i].status === 'fulfilled' && results[i].value) {
                creditMap[id] = results[i].value;
            }
        });

        // Attacher _credits à chaque candidat (null si non enrichi)
        return candidates.map(c => ({ ...c, _credits: creditMap[c.id] || null }));
    },

    // Retourne cast (IDs + noms) et réalisateur en un seul appel /credits
    async getMovieCastAndCrew(movieId) {
        if (!this.apiKey || this.apiKey === 'MOCK') return { castIds: [], castNames: [], director: null };
        try {
            const url = tmdbUrl(`/movie/${movieId}/credits`);
            const resp = await fetch(url);
            if (!resp.ok) return { castIds: [], castNames: [], director: null };
            const data = await resp.json();
            const topCast = (data.cast || []).slice(0, 5);
            const director = (data.crew || []).find(p => p.job === 'Director')?.name || null;
            return {
                castIds: topCast.map(a => a.id),
                castNames: topCast.map(a => a.name),
                director
            };
        } catch (e) { return { castIds: [], castNames: [], director: null }; }
    },

    async getMovieKeywords(movieId) {
        if (!this.apiKey || this.apiKey === 'MOCK') return [];
        try {
            const url = tmdbUrl(`/movie/${movieId}/keywords`);
            const resp = await fetch(url);
            if (!resp.ok) return [];
            const data = await resp.json();
            return data.keywords || [];
        } catch (e) { return []; }
    },

    async getAdvancedDiscovery(preferences, metadata = {}, isReroll = false, page = 1, castIds = []) {
        // Note: le paramètre `page` de l'URL de base est remplacé plus bas par `randomPage`.
        // On le retire ici pour éviter le doublon page=X&...&page=Y (le dernier gagne, mais c'est source de confusion).
        // 10770 = Téléfilm | 99 = Documentaire — exclus par défaut sauf si mood documentaire
        // 16 = Animation | 10751 = Famille — exclus par défaut sauf si l'utilisateur les demande explicitement
        const moodStr = String(preferences.mood || preferences.blendedGenreIds || '');
        const userWantsAnimation = moodStr.includes('16') || preferences.context === 'family'
            || (preferences.exclude || []).includes('animation')
            || (preferences.blendedGenreIds || '').includes('16');
        // On construit withoutGenres comme un Set pour éviter les doublons et les params dupliqués
        const withoutGenres = new Set([10770]); // Téléfilms toujours exclus
        if (!moodStr.includes('99')) withoutGenres.add(99); // Documentaires
        if (!userWantsAnimation) { withoutGenres.add(16); withoutGenres.add(10751); } // Animation + Famille
        let url = tmdbUrl('/discover/movie', { language: this.lang, include_adult: 'false', without_genres: [...withoutGenres].join(',') });

        // ── Filtre plateformes de streaming (FR) ──
        // Les plateformes sont stockées en tant qu'IDs TMDB numériques (ex: "8" pour Netflix)
        const userPlatforms = (preferences._userPlatforms || []).filter(p => p !== 'any');
        const providerIds = userPlatforms.map(p => String(p)).filter(Boolean);
        if (providerIds.length > 0) {
            url += `&watch_region=FR&with_watch_monetization_types=flatrate&with_watch_providers=${providerIds.join('|')}`;
            console.log(`📺 Provider filter actif : IDs ${providerIds.join('|')} (${userPlatforms.join(', ')})`);
        }
        
        // Add with_cast parameter if we have cast IDs from loved movies
        if (castIds && castIds.length > 0) {
            const castIdsString = castIds.slice(0, 3).join(','); // Use top 3 actors max
            url += `&with_cast=${castIdsString}`;
            console.log('🎭 Adding with_cast filter:', castIdsString);
        }

        // 1. Genre filtering — utilise le blend ADN+mood si disponible
        // blendedGenreIds = mood strict + genres récurrents des films de référence
        // Ex: mood=thriller(53) + ADN=horreur(27) → "53,27" → trouve Barbarian, Nope, etc.
        let genreIds = metadata.genre_ids || preferences.blendedGenreIds || preferences.mood;

        // excludeMap :
        // - "horror" → genre 27 (violence/gore)
        // - "scary" → genre 27 UNIQUEMENT (horreur pure : Conjuring, Hereditary, Annabelle...)
        //   ⚠️ NE PAS inclure 53 (Thriller) — un thriller de suspense ≠ "qui fait peur"
        //   American Nightmare = thriller dystopique (53), pas un film d'horreur (27)
        //   Le "suspense angoissant" est géré par pénalité IA (-20 pts), pas par exclusion genre
        // - "sad" → genre 18 (drame)
        // - "slow" → pas de genre TMDb (géré uniquement par scoring IA)
        // - "complex" → pas de genre TMDb (géré uniquement par scoring IA)
        // - "adult" → pas de genre TMDb (TMDb a include_adult=false global ; scoring IA pénalise)
        // - "animation" → genre 16
        // - "none" → rien à exclure (carte blanche)
        const excludeMap = {
            "horror":    [27],
            "scary":     [27],   // horreur pure seulement — thriller (53) n'est PAS "qui fait peur"
            "sad":       [18],
            "slow":      [],
            "complex":   [],
            "adult":     [],
            "animation": [16],
            "teen":      [16, 10751],  // ados/coming-of-age → animation + famille
            "none":      []
        };
        const myExclusions = (preferences.exclude || []).map(ex => excludeMap[ex] || []).flat().filter(Boolean);

        // cleanGenres déclaré en dehors du if pour être accessible dans la section without_genres
        let cleanGenres = '';
        if (genreIds) {
            const genreIdsStr = String(genreIds);
            // Pour le mood Comédie ("35,10751") : utiliser uniquement with_genres=35
            // "35,10751" en logique AND TMDB = Comedy ET Family simultanément → pool minuscule
            // On garde 35 seul pour couvrir toutes les comédies, Family(10751) est optionnel
            const isComedyMood = genreIdsStr.includes('35');
            const baseGenres = isComedyMood ? '35' : genreIdsStr;
            cleanGenres = baseGenres.split(',').filter(id => !myExclusions.includes(Number(id))).join(',');
            if (cleanGenres) url += `&with_genres=${cleanGenres}`;
        }

        // 2. Strict Exclusions (without_genres)
        // ⚠️ Règle : le mood (with_genres) prend toujours la priorité sur les exclusions
        // → on retire de without_genres tout genre déjà présent dans with_genres pour éviter l'impossibilité logique
        const withGenresList = cleanGenres ? cleanGenres.split(',').map(Number).filter(Boolean) : [];
        let excluded = [];
        if (preferences.exclude && Array.isArray(preferences.exclude)) {
            preferences.exclude.forEach(ex => {
                if (excludeMap[ex] && excludeMap[ex].length > 0) {
                    const ids = Array.isArray(excludeMap[ex]) ? excludeMap[ex].join(',') : excludeMap[ex];
                    excluded.push(ids);
                }
            });
        }
        // Filtrer les conflits : si un genre est dans with_genres, ne pas le mettre dans without_genres
        // Fusionner avec withoutGenres (Set) pour éviter les params dupliqués qui s'écrasent mutuellement
        if (excluded.length > 0) {
            excluded.join(',').split(',').map(Number).forEach(id => {
                if (id && !withGenresList.includes(id)) withoutGenres.add(id);
            });
        }
        // Réécrire le paramètre without_genres dans l'URL avec la valeur fusionnée finale
        url = url.replace(/(without_genres=)[^&]+/, `$1${[...withoutGenres].filter(id => !withGenresList.includes(id)).join(',')}`);

        // 3. Social Context Filter
        if (preferences.context === 'family') {
            // Famille = certification max 12, pas de violence/horreur, pas de romance adulte
            // Fusionner les exclusions famille dans withoutGenres (pas de param dupliqué)
            [27, 53, 10749].forEach(id => withoutGenres.add(id));
            url = url.replace(/(without_genres=)[^&]+/, `$1${[...withoutGenres].filter(id => !withGenresList.includes(id)).join(',')}`);
            url += `&certification_country=FR&certification.lte=12&include_adult=false`;
            // Autoriser mystère/suspense doux si mood le demande
            if (preferences.mood === "53" || preferences.mood === "878,9648") {
                url += `&with_genres=9648`; // mystère
            }
        } else if (preferences.context === 'couple') {
            // En couple → boost films avec une dimension relationnelle/émotionnelle forte
            // On n'exclut rien mais on pousse vers des films avec du drame ou de la romance
            // La nuance est gérée au niveau du scoring IA
        } else if (preferences.context === 'friends') {
            // Entre amis → exclure les films très lents/contemplatifs (sauf si pace=mindblow)
            if (preferences.pace === 'easy') {
                url += `&vote_average.gte=6.5`; // Accessible, bien noté
            }
        }

        const era = preferences.era;
        const hasCastFilter = castIds && castIds.length > 0;

        // 4. Duration Filter — minimum 60 min toujours (exclut courts-métrages et mini-docs)
        url += `&with_runtime.gte=60`;
        if (preferences.duration === 'short') {
            url += `&with_runtime.lte=105`;
        } else if (preferences.duration === 'long') {
            url += `&with_runtime.gte=120`;
        }

        // 4b. Language Filter — déduit des films de référence ou conflit duo
        if (preferences._duoLangConflict && preferences._duoLangA && preferences._duoLangB) {
            // Duo conflit : filtre OR (langA ou langB) pour ouvrir le pool aux deux cultures
            const duoLangs = [preferences._duoLangA, preferences._duoLangB].filter(l => l && l !== 'any');
            if (duoLangs.length > 0) {
                url += `&with_original_language=${duoLangs.join('|')}`;
                console.log(`🌍 Duo langue OR : ${duoLangs.join('|')}`);
            }
        } else if (preferences.detectedLanguage) {
            url += `&with_original_language=${preferences.detectedLanguage}`;
            console.log(`🌍 Langue détectée depuis ADN : ${preferences.detectedLanguage}`);
        }

        // 4c. Keywords Filter — style narratif précis déduit des films de référence
        if (preferences.adnKeywordIds?.length > 0) {
            url += `&with_keywords=${preferences.adnKeywordIds.join('|')}`;
            console.log(`🔑 Keywords ADN : ${preferences.adnKeywordIds.join('|')}`);
        }

        // 5. Broad Technical Standards
        if (!hasCastFilter) {
            url += `&vote_average.gte=5.5&vote_count.gte=50`;
        }

        // 6. Era Filter — applied strictly regardless of cast filter
        if (era === 'new') {
            url += `&primary_release_date.gte=2020-01-01`;
        }
        else if (era === 'modern') url += `&primary_release_date.gte=2000-01-01&primary_release_date.lte=2019-12-31`;
        else if (era === 'vintage') url += `&primary_release_date.gte=1975-01-01&primary_release_date.lte=1999-12-31`;
        else if (era === 'retro') url += `&primary_release_date.lte=1974-12-31`;

        // 7. Sort / Pivot Strategy
        const rerollVariant = preferences?.rerollVariant || '';
        if (hasCastFilter) {
            url += `&sort_by=popularity.desc&vote_average.gte=4.5&vote_count.gte=10`;
        } else if (isReroll && rerollVariant === 'hidden_gem') {
            // Pépites : bien notées mais peu connues (évite les blockbusters vus partout)
            url += `&sort_by=vote_average.desc&vote_count.gte=200&vote_count.lte=3000&vote_average.gte=7.2`;
        } else if (isReroll && rerollVariant === 'different_angle') {
            // Angle différent : ouvre le filtre de popularité, tri par date de sortie décroissante
            url += `&sort_by=primary_release_date.desc&vote_average.gte=6.8&vote_count.gte=300`;
        } else if (isReroll) {
            url += `&sort_by=vote_average.desc&vote_count.lte=4000&vote_average.gte=7.0`;
        } else {
            // Seuil min 300 votes pour la qualité, pas de cap max
            url += `&sort_by=vote_average.desc&vote_count.gte=300`;
        }

        const randomPage = isReroll ? Math.floor(Math.random() * 6) + 1 : 1;
        const finalUrl = url + `&page=${randomPage}&_=${Date.now()}`;

        let resp = await fetch(finalUrl, { cache: 'no-store' });
        if (!resp.ok) { console.warn(`getAdvancedDiscovery HTTP ${resp.status}`); return []; }
        let data = await resp.json();
        let results = data.results || [];

        try {
            const resp2 = await fetch(finalUrl.replace(`page=${randomPage}`, `page=${randomPage + 1}`), { cache: 'no-store' });
            const data2 = await resp2.json();
            if (data2.results) results = [...results, ...data2.results];
        } catch(e) { console.warn("Next page fetch failed"); }

        // Option B — Boost pool secondaire selon la polarité émotionnelle détectée
        if ((preferences.mood === '18,10749' || preferences.blendedGenreIds?.includes('18')) && !isReroll) {
            const _sadEx  = (preferences.exclude || []).includes('sad');
            const _couple = preferences.context === 'couple';
            const _noAdn  = !(preferences.lastLovedMovies?.length > 0);
            const _adnRom = (preferences.lastLovedMovies || []).some(m => (m.genre_ids || []).includes(10749));
            const _romancePolarityActive = (_adnRom && _sadEx) || (_noAdn && _couple && _sadEx);

            if (_romancePolarityActive) {
                // POLARITÉ A → boost films Romance (genre 10749) bien notés
                try {
                    const romanceUrl = tmdbUrl('/discover/movie', { language: this.lang, include_adult: 'false', with_genres: '10749', 'vote_average.gte': '6.5', 'vote_count.gte': '300', sort_by: 'vote_average.desc', page: '1' });
                    const romResp = await fetch(romanceUrl, { cache: 'no-store' });
                    const romData = await romResp.json();
                    if (romData.results?.length) {
                        results = [...results, ...romData.results];
                        console.log(`💕 Boost romance : +${romData.results.length} films romantiques ajoutés au pool`);
                    }
                } catch(e) { console.warn('Boost romance failed', e); }
            } else {
                // POLARITÉ B → boost biopic/histoire vraie inspirante
                try {
                    // TMDB keyword IDs : 14769=biography, 9798=based on a true story, 4565=underdog
                    const inspiringUrl = tmdbUrl('/discover/movie', { language: this.lang, include_adult: 'false', with_genres: '18', 'with_keywords': '14769|9798|4565', 'vote_average.gte': '7.0', 'vote_count.gte': '500', sort_by: 'vote_average.desc', page: '1' });
                    const inspr = await fetch(inspiringUrl, { cache: 'no-store' });
                    const insprData = await inspr.json();
                    if (insprData.results?.length) {
                        results = [...results, ...insprData.results];
                        console.log(`🌟 Boost inspirant : +${insprData.results.length} films biopic/histoire vraie ajoutés au pool`);
                    }
                } catch(e) { console.warn('Boost inspirant failed', e); }
            }
        }

        // Fallback sans keywords si trop peu de résultats
        if (results.length < 5 && preferences.adnKeywordIds?.length > 0) {
            console.log('⚠️ Keywords trop restrictifs, fallback sans keywords');
            const urlNoKw = finalUrl.replace(/&with_keywords=[^&]+/, '');
            try {
                const r = await fetch(urlNoKw, { cache: 'no-store' });
                const d = await r.json();
                if (d.results?.length > results.length) results = d.results;
            } catch(e) {}
        }

        let finalResults = [...results];

        // T2 FALLBACK si résultats trop faibles
        if (finalResults.length < 3) {
            let t2Url = tmdbUrl('/discover/movie', { language: this.lang, include_adult: 'false', 'vote_count.gte': '20', sort_by: 'popularity.desc', page: String(page) });
            if (genreIds) t2Url += `&with_genres=${genreIds}`;
            if (excluded.length > 0) t2Url += `&without_genres=${excluded.join(',')}`;
            if (hasCastFilter) t2Url += `&with_cast=${castIds.slice(0,3).join(',')}`;
            if (era === 'new') t2Url += `&primary_release_date.gte=2010-01-01`;
            t2Url += `&_=${Date.now()}`;
            const t2Resp = await fetch(t2Url, { cache: 'no-store' });
            if (!t2Resp.ok) { console.warn(`T2 fallback HTTP ${t2Resp.status}`); }
            const t2Data = t2Resp.ok ? await t2Resp.json() : { results: [] };
            const t2Res = t2Data.results || [];
            finalResults = [...finalResults, ...t2Res.filter(r => !finalResults.some(old => old.id === r.id))];
        }

        if (finalResults.length === 0) {
            console.log("FALLBACK T3 déclenché (Aucun film trouvé avec ces filtres !)");
            let t3Url = tmdbUrl('/discover/movie', { language: this.lang, include_adult: 'false', sort_by: 'popularity.desc' });
            if (era === 'new') t3Url += `&primary_release_date.gte=2020-01-01`;
            if (excluded.length > 0) t3Url += `&without_genres=${excluded.join(',')}`;
            if (castIds && castIds.length > 0) t3Url += `&with_cast=${castIds.slice(0,3).join(',')}`;
            const t3Resp = await fetch(t3Url + `&_=${Date.now()}`);
            if (!t3Resp.ok) { console.warn(`T3 fallback HTTP ${t3Resp.status}`); }
            const t3Data = t3Resp.ok ? await t3Resp.json() : { results: [] };
            finalResults = t3Data.results || [];
        }

        if (this.apiKey === 'MOCK' || !this.apiKey) {
            console.log("🛠️ Testing with Mock Data...");
            return Array.from({ length: 20 }, (_, i) => ({
                id: 101 + i,
                title: `Peux-tu me surprendre ? ${i+1}`,
                release_date: (2000 + i) + '-01-01',
                genre_ids: [28, 53],
                vote_average: 8.5,
                vote_count: 5000,
                poster_path: '/r24A810N5T6v3F0Z69o6U0mS.jpg', // Dummy real poster path from TMDB
                overview: "Ceci est une recommandation test générée par l'IA pour valider l'interface. Un film captivant qui vous tiendra en haleine."
            }));
        }
        return finalResults.slice(0, 40);
    }
};

// ─────────────────────────────────────────────────────────────────
//  GENRE ID → LABEL MAP  (for enriched candidate context)
// ─────────────────────────────────────────────────────────────────
const GENRE_LABELS = {
    28: "Action", 12: "Aventure", 16: "Animation", 35: "Comédie",
    80: "Crime", 99: "Documentaire", 18: "Drame", 10751: "Famille",
    14: "Fantastique", 36: "Histoire", 27: "Horreur", 10402: "Musique",
    9648: "Mystère", 10749: "Romance", 878: "Science-Fiction",
    10770: "Téléfilm", 53: "Thriller", 10752: "Guerre", 37: "Western"
};

function formatGenres(ids) {
    if (!ids || ids.length === 0) return "Non précisé";
    return ids.map(id => GENRE_LABELS[id] || id).join(', ');
}

// ─────────────────────────────────────────────────────────────────
//  Résume les films aimés en "archétypes" pour l'analyse ADN
// ─────────────────────────────────────────────────────────────────
function buildDNAArchetypes(likedMovies) {
    if (!likedMovies || likedMovies.length === 0) return "Aucun film de référence fourni.";
    return likedMovies.map(m => {
        const year = (m.release_date || '').split('-')[0] || '?';
        let desc = `"${m.title}" (${year})`;
        if (m._director) desc += ` — réal. ${m._director}`;
        if (m._castNames?.length > 0) desc += ` — avec ${m._castNames.slice(0, 3).join(', ')}`;
        return desc;
    }).join('\n');
}

export const openaiService = {
    apiKey: '',

    init(key) {
        this.apiKey = key;
    },

    // Résout la clé effective : localStorage > fallback dev
    _resolveKey() {
        return this.apiKey || _DEV_KEY;
    },

    async getCinemaTrivia(lang = 'fr') {
        if (!this._resolveKey()) return lang === 'en' ? "Getting your films ready..." : "Préparation de tes films...";
        try {
            const prompt = lang === 'en'
                ? "Give me a very short and surprising cinema fact (max 15 words)."
                : "Donne-moi une anecdote très courte et surprenante sur le cinéma (max 15 mots).";
            const resp = await fetch(OPENAI_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${this._resolveKey()}`
                },
                body: JSON.stringify({
                    model: "gpt-4o-mini",
                    messages: [{ role: "user", content: prompt }],
                    max_tokens: 50
                })
            });
            if (!resp.ok) throw new Error("OpenAI API Fetch Error");
            const data = await resp.json();
            const content = data.choices?.[0]?.message?.content;
            if (!content) return lang === 'en' ? "Cinema is the art of making pleasure last." : "Le cinéma, c'est l'art de faire durer le plaisir.";
            return content.trim();
        } catch (e) {
            if (e.name === 'TypeError' && e.message === 'Failed to fetch') {
                console.error("❌ OpenAI CORS Error: Browser blocked the request. You might need a proxy or a browser extension (like CORS Unblock) to run this locally.");
            } else {
                console.error("❌ OpenAI Trivia Error:", e);
            }
            return lang === 'en' ? "Cinema is the art of making pleasure last." : "Le cinéma, c'est l'art de faire durer le plaisir.";
        }
    },

    // ─────────────────────────────────────────────────────────────
    //  ÉTAPE 1 : EXTRACTION DES MÉTADONNÉES (ADN v3 — Style Narratif)
    //  Analyse profonde du profil cinéphile pour générer des filtres
    //  TMDB précis + déduire le style narratif, le rythme, l'esthétique
    //  visuelle et les archétypes émotionnels du spectateur.
    // ─────────────────────────────────────────────────────────────
    async extractMetadata(userAnswers, isReroll = false, seenTitles = []) {
        if (!this._resolveKey()) return {};
        try {
            const eraLabel = userAnswers.era === 'new' ? '2020 à aujourd\'hui'
                : userAnswers.era === 'modern' ? '2000 à 2020'
                : userAnswers.era === 'vintage' ? 'Vintage 1975-1999'
                : 'Toutes époques';

            const dnaBlock = buildDNAArchetypes(userAnswers.lastLovedMovies || []);
            const seenBlock = seenTitles.length > 0
                ? `\n[FILMS DEJA SUGGERES - EXCLURE ABSOLUMENT] : ${seenTitles.join(', ')}\n`
                : '';

            const durationLabel = userAnswers.duration === 'short' ? 'Film court (< 1h45)'
                : userAnswers.duration === 'long' ? 'Long format (> 2h)'
                : 'Peu importe';

            // ── Bloc profil d'apprentissage (films notés par l'utilisateur) ──
            const profile = userAnswers._ratingProfile;
            const learningBlock = (() => {
                if (!profile || profile.loved.length === 0) return '';
                const lovedStr    = profile.loved.map(r => `${r.title} (${r.rating}★)`).join(', ');
                const dislikedStr = profile.disliked.length > 0
                    ? `\n[PROFIL APPRIS - Films peu appréciés (1-2★)] : ${profile.disliked.map(r => r.title).join(', ')}\n→ Évite les films dans le même registre stylistique et narratif que ceux-ci.`
                    : '';
                return `
[PROFIL APPRIS PAR L'IA - Films adorés par cet utilisateur (4-5★)] : ${lovedStr}
→ Ces films révèlent son goût PROFOND et permanent — indépendamment de la session en cours.
→ Utilise-les pour calibrer le NIVEAU D'EXIGENCE et l'ESTHÉTIQUE des suggestions.${dislikedStr}
⚡ RÈGLE LEARNING : Le profil appris ENRICHIT l'ADN style mais ne REMPLACE PAS le mood session. Priorité : mood session > ADN films référence > profil appris.`;
            })();

            const prompt = `Tu es un cinéphile expert et psychologue du goût. Ton rôle : décoder le profil narratif et émotionnel d'un spectateur pour calibrer les filtres TMDB.

═══════════════════════════════════════════
PROFIL SPECTATEUR COMPLET
═══════════════════════════════════════════
[CONTEXTE SOCIAL] : ${userAnswers.contextLabel}
[ENERGIE / MOOD] : ${userAnswers.moodLabel}${userAnswers._subMoodLabel ? `\n[SOUS-MOOD PRÉCIS] : "${userAnswers._subMoodLabel}" — cherche en priorité des films de ce registre exact.` : ''}
[BATTERIE MENTALE] : ${userAnswers.pace === 'easy' ? 'Cerveau débranché — rien de trop complexe' : userAnswers.pace === 'complex' ? 'Attentif — scénario bien construit bienvenu' : userAnswers.pace === 'mindblow' ? 'Mind-blow — intrigue dense et retournements exigés' : 'Peu importe'}
[DUREE DISPONIBLE] : ${durationLabel}
[LANGUE / ORIGINE] : ${(l => l && l !== 'any' ? ({fr:'Films français',en:'Films américains/anglais',ko:'Films asiatiques',es:'Films hispaniques',any:'Peu importe'}[l] || l) : 'Peu importe — toutes origines acceptées')(userAnswers.detectedLanguage || userAnswers.language)}
[FILMS DE REFERENCE (ADN STYLE)] : ${dnaBlock || 'Aucun fourni'}
[EXCLUSIONS STRICTES] : ${userAnswers.excludeLabels || "Aucune"}
[EPOQUE] : ${eraLabel}
${learningBlock}
${seenBlock}

═══════════════════════════════════════════
ANALYSE ADN NARRATIVE (Chain-of-Thought)
═══════════════════════════════════════════

⚠️ RÈGLE CRITIQUE SUR LES FILMS DE RÉFÉRENCE :
Les films de référence servent UNIQUEMENT à calibrer le STYLE et la QUALITÉ narrative.
Ils ne définissent PAS le genre. Le genre vient EXCLUSIVEMENT du champ [ENERGIE / MOOD].
Ex : si l'utilisateur cite "Get Out" (horreur) mais que le mood est "comédie", cherche une comédie au style soigné — pas un film d'horreur.

ÉTAPE 1 — DÉCODAGE ADN STYLE NARRATIF
Analyse les films de référence et réponds à ces questions :
→ Quel est le STYLE DE MISE EN SCÈNE privilégié ? (haletant/contemplatif/épique/intime/viscéral)
→ Quel est le RYTHME NARRATIF préféré ? (montage cut/plans séquences/récit non-linéaire/récit linéaire)
→ Quel est l'ARCHÉTYPE ÉMOTIONNEL ? (catharsis/adrénaline/réflexion/évasion/empathie)
→ Quel est le NIVEAU D'EXIGENCE NARRATIVE ? (divertissement pur / scénario construit / œuvre complexe)
→ Quelle est l'ESTHÉTIQUE VISUELLE ? (réaliste/stylisée/sombre/lumineuse/futuriste/brute)

ÉTAPE 2 — SYNTHÈSE POUR TMDB
→ Genre principal : mood "${userAnswers.moodLabel}" (${userAnswers.mood}).
${userAnswers.blendedGenreIds && userAnswers.blendedGenreIds !== userAnswers.mood
    ? `→ GENRE BLEND DÉTECTÉ : les films de référence incluent aussi les genres [${userAnswers.blendedGenreIds}]. Tes suggestions DOIVENT explorer ce croisement de genres — c'est là que se trouvent les meilleures recommandations.`
    : ''}
→ Keywords TMDB précis : mots-clés de niche ciblant le style narratif, pas juste le genre.
→ 12 titres PRÉCIS incarnant la fusion mood + style ADN + blend genres. Priorise :
   - Films dans le croisement exact des genres détectés (ex: horror-thriller si blend 27+53)
   - Films que l'utilisateur ne connaît probablement pas (évite les blockbusters ultra-connus)
   - Films récents si era="${eraLabel}"
   - Même intensité émotionnelle que les films ADN
   - Variété de sous-genres et de pays
   ${seenTitles.length > 0 ? 'AUCUN des titres déjà vus.' : ''}

ÉTAPE 3 — UNIVERS CULTUREL & REPRÉSENTATION (psychologie de l'identification)
Les films de référence ne sont pas juste des marqueurs de goût — ils sont des marqueurs d'IDENTITÉ CULTURELLE.
Les recherches en psychologie (Self-congruity theory, Tajfel & Turner 1979, parasocial relationships) montrent que les spectateurs se projettent dans les films qui reflètent leur univers culturel.

→ Quel est l'UNIVERS CULTUREL dominant de ces films ?
   Exemples : comédie afro-américaine, buddy-movie afro-français, cinéma de banlieue française, comédie afro-caribéenne, film d'auteur coréen, drama familial indien, etc.
→ Y a-t-il une COMMUNAUTÉ ou un groupe social représenté à l'écran ? (acteurs noirs américains, personnages latinos, humour communautaire français, casting afro-européen, etc.)
→ Quel est le STYLE DE LA COMÉDIE si applicable ? (comédie de situation, buddy-comedy, slapstick, comédie sociale, satire communautaire, etc.)

⚡ CE SIGNAL CULTUREL EST PRIORITAIRE pour tes suggestions :
   Si les films de référence sont clairement dans un univers culturel précis (ex: "comédie afro-américaine"), TU DOIS proposer des films du MÊME univers culturel.
   Ex avec Think Like a Man + Case Départ : propose Girls Trip, Barbershop, About Last Night, Ride Along, Fous d'amour, Qu'est-ce qu'on a fait au Bon Dieu?, Coming 2 America — PAS des comédies génériques blanches américaines.
   L'utilisateur veut se retrouver dans ce qu'il regarde — c'est le principe de la résonance culturelle.
${userAnswers.rerollVariant === 'hidden_gem' ? `
🔄 VARIANTE RE-ROLL — PÉPITES MÉCONNUES :
Tu dois proposer des films MOINS CONNUS mais de grande qualité.
→ Évite les blockbusters (Marvel, Disney, films > 100M$ box-office) sauf s'ils correspondent parfaitement.
→ Cherche des films entre 200k et 2M de spectateurs TMDB — des "films de cinéphile" qu'on découvre avec surprise.
→ Pense : films indépendants, productions internationales méconnues, perles oubliées des années 90-2000.` : ''}
${userAnswers.rerollVariant === 'different_angle' ? `
🔄 VARIANTE RE-ROLL — ANGLE DIFFÉRENT :
L'utilisateur a déjà vu des suggestions. Il veut explorer un REGISTRE DIFFÉRENT du même mood.
→ Change l'époque : si les 1ères suggestions étaient récentes, propose du vintage ou inversement.
→ Change le sous-genre : si les 1ères étaient des comédies romantiques, propose des comédies d'action ou dramatiques.
${(userAnswers.language && userAnswers.language !== 'any') ? `→ ⛔ LANGUE VERROUILLÉE : L'utilisateur a choisi "${({fr:'Films français',en:'Films américains/anglais',ko:'Films asiatiques',es:'Films hispaniques'}[userAnswers.language] || userAnswers.language)}". NE CHANGE JAMAIS la langue/nationalité. Reste dans cette langue.` : `→ Change la nationalité : explore un cinéma différent (européen, asiatique, latino…).`}
→ L'objectif : même émotion cible, chemin complètement différent.` : ''}

${userAnswers.context === 'family' ? '⛔ CONTRAINTE ABSOLUE : Contexte famille = ZÉRO contenu adulte/violent. Exclure genre_ids : 27 (horreur), 53 (thriller intense), 18 (drames lourds).' : ''}

${(userAnswers.language && userAnswers.language !== 'any') ? `⛔ RÈGLE LANGUE ABSOLUE — NE PAS CONTOURNER :
L'utilisateur a sélectionné "${({fr:'Films français',en:'Films américains/anglais',ko:'Films asiatiques',es:'Films hispaniques'}[userAnswers.language] || userAnswers.language)}".
→ Tous tes titres dans "specific_suggestions" DOIVENT être dans cette langue originale.
→ Pour "Films américains/anglais" : UNIQUEMENT des films en anglais (original_language = "en"). JAMAIS de films espagnols, français, coréens, latins ou autres.
→ Cette règle est ABSOLUE. Elle prime sur toute logique de variété ou d'exploration culturelle.` : ''}

⛔ RÈGLE PAR DÉFAUT — AUDIENCE ADULTE :
Sauf si l'utilisateur mentionne explicitement des films d'animation, des films pour enfants/ados, ou un contexte famille : ne propose JAMAIS de films d'animation (genre_ids: 16), de films familiaux (genre_ids: 10751), ou de films clairement destinés aux moins de 15 ans (ex: films Disney classiques, Pixar, DreamWorks, films de super-héros pour enfants).
→ L'audience par défaut est adulte. Adapte-toi UNIQUEMENT si les films de référence ou le contexte indiquent clairement un intérêt pour ce type de contenu.

Réponds UNIQUEMENT par ce JSON strict (pas de markdown, pas de texte autour) :
{
  "dna_analysis": "string (2-3 phrases) décrivant le style narratif et le niveau d'exigence détectés",
  "theme_interpretation": "string (1-2 phrases) synthèse mood + style pour guider la recherche",
  "cultural_universe": "string (1 phrase) décrivant l'univers culturel détecté — ex: 'comédie afro-américaine avec ensemble cast diversifié' ou 'buddy-comedy afro-français satirique' ou 'comédie populaire française multiculturelle'. Vide si aucun signal culturel précis.",
  "excluded_from_prompt": ["Titre Film Cité"],
  "genre_ids": "id1,id2",
  "specific_suggestions": ["Titre 1"],
  "mood_tags": ["tag1", "tag2"]
}`;
            const messages = [{ role: "user", content: prompt }];

            // --- MODIFICATION PROXY ---
            // On utilise le proxy local (port 8001) pour éviter l'erreur CORS
            const resp = await fetch(OPENAI_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this._resolveKey()}`
                },
                body: JSON.stringify({
                    model: "gpt-4o-mini",
                    messages: messages,
                    temperature: 0.7, // Plus élevé pour varier les suggestions à chaque recherche
                    response_format: { type: "json_object" }
                })
            });
            if (!resp.ok) throw new Error("OpenAI API Extract Error");
            const data = await resp.json();
            const content = data.choices?.[0]?.message?.content;
            let parsed = {};
            try {
                parsed = content ? JSON.parse(content) : {};
            } catch (jsonErr) {
                console.warn("AI returned invalid JSON:", jsonErr);
            }

            console.log("🧬 ADN Narratif:", parsed.dna_analysis);
            console.log("🎨 Style Visuel:", parsed.narrative_style);
            console.log("🎭 Archétype Émotionnel:", parsed.emotional_archetype);
            console.log("🎯 Thème Interprété:", parsed.theme_interpretation);
            return parsed;
        } catch (e) {
            if (e.name === 'TypeError' && e.message === 'Failed to fetch') {
                console.error("❌ OpenAI CORS Error: Browser blocked the request. This is expected when calling OpenAI from a browser. Solution: Use a backend proxy or a CORS-bypass extension for local testing.");
                console.error("❌ Proxy CORS : démarre python3 proxy.py sur le port 8001");
            } else {
                console.error("Extraction error:", e);
            }
            // FAIL-SAFE : retourne objet vide, l'app utilisera les filtres TMDb directs
            return {};
        }
    },

    // ─────────────────────────────────────────────────────────────
    //  ÉTAPE 3 : CLASSEMENT PROFOND PAR IA (Refonte v3)
    //
    //  Scoring multicritères à PONDÉRATION DYNAMIQUE :
    //  — Mode "Envie Précise"  : Thème 45% | ADN 25% | Mood 20% | Qualité 10%
    //  — Mode "ADN Libre"      : ADN 40%   | Mood 30% | Qualité 20% | Thème 10%
    //
    //  + Garantie de DIVERSITÉ du top 3 (genres / styles différents)
    //  + Match reasons ancrées dans les films aimés ET l'envie
    // ─────────────────────────────────────────────────────────────
    async getDeepRecommendations(likedMovies, preferences, candidates = [], isReroll = false, excludedIds = [], lang = 'fr') {
        if (!this._resolveKey()) return [];

        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 30000);

        const user_dna = buildDNAArchetypes(likedMovies);
        const eraLabel = preferences.era === 'new' ? '2020 à aujourd\'hui'
            : preferences.era === 'modern' ? '2000-2020'
            : preferences.era === 'vintage' ? 'Vintage 1975-1999'
            : 'Toutes époques';
        const durationLabel = preferences.duration === 'short' ? 'Film court (< 1h45)'
            : preferences.duration === 'long' ? 'Long format (> 2h)'
            : 'Peu importe';

        // ── Pondération fixe : ADN style 40% | Mood 30% | Qualité 20% | Thème 10% ──
        const weights = { dna: 40, mood: 30, quality: 20, theme: 10 };
        const weightingDescription = `MODE ADN LIBRE :
  → ADN Style Cinéphile = ${weights.dna} pts MAX (PRIORITÉ — style narratif, rythme, esthétique)
  → Mood/Énergie = ${weights.mood} pts max
  → Qualité Objective = ${weights.quality} pts max
  → Thème = ${weights.theme} pts max (bonus secondaire)`;

        // ── Enrichissement des candidats avec contexte narratif + cast/réalisateur (B-fix) ──
        const enrichedCandidates = candidates.map(m => {
            const year = (m.release_date || '').split('-')[0] || '?';
            const rating = m.vote_average ? `${Number(m.vote_average).toFixed(1)}/10` : 'N/A';
            const votes = m.vote_count ? `${m.vote_count.toLocaleString()} votes` : '';
            const genres = formatGenres(m.genre_ids || []);
            const overview = m.overview ? m.overview.substring(0, 200) : 'Pas de synopsis.';
            // Cast + réalisateur si disponibles (enrichCandidatesWithCast a été appelé en amont)
            const credits = m._credits;
            const dirLine  = credits?.director    ? ` | Réal: ${credits.director}` : '';
            const castLine = credits?.castNames?.length > 0
                ? ` | Avec: ${credits.castNames.slice(0, 3).join(', ')}`
                : '';
            return `- [ID:${m.id}] "${m.title}" (${year}) | ${genres} | ⭐${rating} (${votes})${dirLine}${castLine}\n  └─ ${overview}`;
        }).join('\n');

        // ── Ancrage ADN pour les match reasons ──
        const dnaAnchor = likedMovies && likedMovies.length > 0
            ? `Films de référence de cet utilisateur : ${user_dna}. Dans tes raisons de match, fais des LIENS EXPLICITES avec ces films quand c'est pertinent (ex: "Dans la lignée de [Film X]", "Le même souffle que [Film Y]").`
            : `Pas de films de référence fournis. Base tes raisons sur le mood et l'envie.`;

        // ── Contexte re-roll ──
        const rerollVariant = preferences?.rerollVariant || '';
        const rerollContext = isReroll
            ? `\n🔄 MODE RE-ROLL ACTIF : L'utilisateur veut de la NOUVEAUTÉ. IDs exclus : [${excludedIds.join(', ')}]. Favorise impérativement la diversité dans le top 3.
${rerollVariant === 'hidden_gem' ? `💎 VARIANTE PÉPITES : L'utilisateur cherche des films moins connus mais excellents. Favorise les films avec peu de votes TMDB (< 100k) mais très bien notés. Pénalise les blockbusters ultra-populaires si des alternatives de qualité existent. Dans tes match_reasons, souligne que c'est une découverte rare.` : ''}
${rerollVariant === 'different_angle' ? `🔀 VARIANTE ANGLE DIFFÉRENT : Assure-toi que le top 3 explore un registre/sous-genre/époque DIFFÉRENT des suggestions précédentes. Si les 1ères étaient des comédies romantiques américaines récentes, propose maintenant des films d'un autre style (comédie d'action, drame léger, film européen, vintage...). Même émotion cible, chemin différent.` : ''}`
            : '';

        // ── Mapping genres TMDB → noms lisibles (déclaré ici pour éviter TDZ) ──
        const GENRE_ID_NAMES = {
            18: 'Drame', 10749: 'Romance', 28: 'Action', 12: 'Aventure',
            53: 'Thriller', 27: 'Horreur', 35: 'Comédie', 10751: 'Famille',
            878: 'Science-Fiction', 9648: 'Mystère', 16: 'Animation',
            36: 'Histoire', 80: 'Crime', 99: 'Documentaire', 10402: 'Musique'
        };

        // ── Personnalisation depuis l'historique CineaMatch IA ──
        const userFavGenres = preferences._userFavGenres || [];
        const userPersonalization = userFavGenres.length > 0
            ? `\n\n✨ PROFIL CINÉPHILE PERSONNALISÉ (historique CineaMatch IA) :
  Genres que cet utilisateur apprécie historiquement : ${userFavGenres.map(id => GENRE_ID_NAMES[id] || id).join(', ')}
  → Accorde +5 pts BONUS aux films qui incluent ces genres, SANS jamais sacrifier la cohérence avec le mood actuel.
  → Ces genres reflètent ses goûts à long terme — ils peuvent orienter à égalité entre deux films similaires.`
            : '';

        // ── Plateformes de streaming préférées ──
        const userPlatforms = preferences._userPlatforms || [];
        const streamingContext = userPlatforms.length > 0
            ? `\n\n📺 PLATEFORMES DE STREAMING DE L'UTILISATEUR : ${userPlatforms.join(', ')}
  → Parmi les films qui correspondent au mood, PRÉFÈRE ceux disponibles sur ces plateformes (+3 pts bonus).
  → Si plusieurs films sont équivalents, favorise celui disponible sur ces plateformes.
  → Ne sacrifie JAMAIS la cohérence mood/genre pour cette contrainte.`
            : '';

        // ── Préférences de recommandation par défaut (vibe, époque, origine, exclusions) ──
        const rp = preferences._recoPrefs || {};
        const rpVibes      = rp.vibes      || [];
        const rpEpoques    = rp.epoques    || [];
        const rpOrigines   = rp.origines   || [];
        const rpExclusions = rp.exclusions || [];
        const hasRecoPrefs = rpVibes.length || rpEpoques.length || rpOrigines.length || rpExclusions.length;
        const recoPrefsContext = hasRecoPrefs
            ? `\n\n🎯 PRÉFÉRENCES PERMANENTES CONFIGURÉES PAR L'UTILISATEUR :${
                rpEpoques.length && !rpEpoques.includes("Peu importe l'époque")
                                  ? `\n  📅 Époque : ${rpEpoques.join(', ')} — favorise ces périodes` : ''}${
                rpOrigines.length && !rpOrigines.includes('Monde entier')
                                  ? `\n  🌍 Pays d'origine : ${rpOrigines.join(', ')} — favorise ces origines` : ''}${
                rpExclusions.length ? `\n\n  ⛔ RÈGLES ABSOLUES — SANS EXCEPTION :\n${rpExclusions.map(e => `    • JAMAIS de films avec : ${e}`).join('\n')}\n  Ces règles s'appliquent même si un film est excellent par ailleurs. Élimination immédiate.` : ''}`
            : '';

        // ── Contexte Duo Mode ──
        const LANG_LABELS = { fr: 'Films français', en: 'Films américains/anglais', ko: 'Films asiatiques', es: 'Films hispaniques/latinos', any: 'Indifférent' };
        const langConflictNote = preferences.isDuoMode && preferences._duoLangConflict
            ? `\n  ⚡ CONFLIT D'ORIGINE : A préfère "${LANG_LABELS[preferences._duoLangA] || preferences._duoLangA}" vs B "${LANG_LABELS[preferences._duoLangB] || preferences._duoLangB}"
  → Cherche une co-production, un film d'auteur international, ou un film universellement adopté par les deux cultures.
  → Exemples : Intouchables (FR-INT), La Haine, Amélie, The Artist, OSS 117 — ou un film américain très francophile.
  ⛔ Ne choisis PAS 3 films tous dans la même langue.`
            : '';
        const eraConflictNote = preferences.isDuoMode && preferences._duoEraConflict
            ? `\n  ⚡ CONFLIT D'ÉPOQUE : A veut du "${preferences._duoEraLabelA || preferences._duoEraA}" vs B du "${preferences._duoEraLabelB || preferences._duoEraB}"
  → Cherche un film INTEMPOREL : soit un classique qui a vieilli parfaitement, soit un film récent au style rétro.
  → Exemples : The Shawshank Redemption, Parasite, Goodfellas, The Godfather, Drive, Blade Runner 2049.
  → Privilégie des films dont l'année n'est pas leur première qualité — des œuvres qui transcendent leur époque.
  ⛔ Ne choisis PAS 3 films tous du même siècle.`
            : '';

        // Exclusions duo : absolues vs souples
        const duoHardEx  = preferences._duoHardExclude  || [];
        const duoSoftExA = preferences._duoSoftExcludeA || [];
        const duoSoftExB = preferences._duoSoftExcludeB || [];
        const duoExclusionNote = preferences.isDuoMode && (duoHardEx.length || duoSoftExA.length || duoSoftExB.length)
            ? `\n\n⛔ EXCLUSIONS DUO :${
                duoHardEx.length  ? `\n  🔴 ABSOLUES (les deux refusent) → Score = 0 forcé : ${duoHardEx.join(', ')}` : ''}${
                duoSoftExA.length ? `\n  🟡 Pénalité A seulement (-20 pts) : ${duoSoftExA.join(', ')} — accepté si c'est le meilleur compromis` : ''}${
                duoSoftExB.length ? `\n  🟡 Pénalité B seulement (-20 pts) : ${duoSoftExB.join(', ')} — accepté si c'est le meilleur compromis` : ''}`
            : '';

        const PACE_LABELS = { easy: 'film simple/accessible', complex: 'film à scénario construit', mindblow: 'film mind-blow/complexe', any: 'indifférent' };
        const duoPaceNote = preferences.isDuoMode && preferences._duoPaceConflict
            ? `\n  ⚡ CONFLIT DE COMPLEXITÉ : A préfère un "${PACE_LABELS[preferences._duoPaceA] || preferences._duoPaceA}" vs B un "${PACE_LABELS[preferences._duoPaceB] || preferences._duoPaceB}"
  → Cherche un film au scénario accessible mais avec une profondeur émotionnelle — simple à suivre mais avec de la substance. Évite les films trop cryptiques ET les films trop superficiels.`
            : '';

        const duoContext = preferences.isDuoMode
            ? `\n\n👫 MODE DUO — RÈGLE ABSOLUE ET NON NÉGOCIABLE :
Ces recommandations sont pour DEUX personnes avec des envies DIFFÉRENTES :
  → Personne A veut : ${preferences.duoMoodLabelA || '?'}
  → Personne B veut : ${preferences.duoMoodLabelB || '?'}${langConflictNote}${eraConflictNote}${duoPaceNote}${duoExclusionNote}

CHAQUE film du top 3 DOIT être un vrai compromis qui satisfait les DEUX simultanément.

EXEMPLES DE COMPROMIS PARFAITS selon les combos de moods :
  • Suspense + Légèreté → Knives Out, Game Night, The Nice Guys, Murder Mystery, Clue, Palm Springs, Catch Me If You Can
  • Action + Émouvant → The Pursuit of Happyness, Rocky, Whiplash, Eddie the Eagle, Ford v Ferrari
  • Horreur + Comédie → Get Out (tension + humour noir), Shaun of the Dead, Ready or Not
  • SF + Romance → Interstellar, Midnight in Paris, About Time, Her
  • Thriller + Romance → Gone Girl, Crazy Rich Asians, The Proposal (avec tension)

⛔ SCORE = 0 FORCÉ (pas de -35, mais ZÉRO) pour tout film dont le genre principal est à l'opposé direct d'un des deux moods.
  Exemple : film d'horreur pur (Saw, Scream, Hereditary) si l'un veut Légèreté → Score = 0.
  Exemple : comédie légère sans aucune tension si l'un veut Suspense → Score = 0.
⛔ INTERDIT : Recommander 3 films qui plaisent tous uniquement à la même personne.
✅ RÈGLE D'OR DU #1 : Le premier film DOIT être le compromis le plus évident — les deux moods présents dans le même film. Un film où les DEUX personnes peuvent dire "oui" immédiatement.`
            : '';

        // ── Profil d'âge de l'utilisateur ──
        const ageProfile = preferences._ageProfile || null;
        const ageContext = ageProfile
            ? `\n\n👤 PROFIL D'ÂGE : ${ageProfile.label}
  → ${ageProfile.hint}${ageProfile.excludeAdult ? '\n  ⛔ INTERDIT ABSOLU : tout contenu adulte explicite, nudité, violence graphique, thèmes trop lourds. Score = 0 forcé pour ces films.' : ''}`
            : '';

        // ── Contexte social → impact sur le scoring ──
        const contextImpact = preferences.context === 'family'
            ? `\n⛔ CONTEXTE FAMILLE — CONTRAINTE ABSOLUE ET NON NÉGOCIABLE :
Score = 0 FORCÉ pour TOUT film qui correspond à l'un de ces critères, MÊME SI son genre est "Animation" ou "SF" :
  • Violence graphique, sang, morts violentes, combats brutaux (ex: Batman TDK Returns, Watchmen, Logan, Old Boy, Deadpool)
  • Thèmes adultes : sexualité, addiction, trauma, horreur psychologique
  • Ton sombre, nihiliste ou désespéré (ex: films de superhéros "dark", dystopies violentes)
  • Certification française 16+ ou 18+ (ou équivalent)
  • Animation pour adultes (ex: Batman The Dark Knight Returns, Invincible, The Boys : INTERDIT)

✅ SEULS les films accessibles à des enfants de 8-12 ans sont autorisés en contexte famille :
  • SF familiale : WALL-E, Zootopie, Moana, Les Indestructibles, Big Hero 6, En route !, Stitch
  • Action/Aventure familiale : Indiana Jones, Star Wars (épisodes principaux), Jumanji (2017), Ghostbusters (1984)
  • SF légère : E.T., Retour vers le futur, Gremlins (avec prudence), Men in Black (1)

🚨 RÈGLE D'OR : Si tu hésites entre deux films dont l'un est "plus sûr" pour une famille, choisis TOUJOURS le plus sûr. Le contexte famille prime sur tout le reste — ADN, références, diversité.
🚨 L'ADN des films de référence (ex: Ready Player One) ne doit PAS pousser vers des films adultes/sombres. Le contexte famille écrase l'ADN pour tout ce qui concerne la violence et le ton.`
            : preferences.context === 'couple'
            ? `\n💑 CONTEXTE COUPLE : Favorise les films avec une dimension émotionnelle forte, une tension relationnelle, ou une histoire qui invite à la discussion post-visionnage. +10 pts bonus pour les films qui créent un "effet miroir" dans une relation.`
            : preferences.context === 'friends'
            ? `\n👥 CONTEXTE AMIS : Favorise les films accessibles, qui se regardent bien en groupe, avec un rythme soutenu. Évite les films trop intimes ou trop contemplatifs qui perdent leur force en groupe.`
            : `\n🎬 CONTEXTE SOLO : Aucune contrainte particulière. L'expérience peut être immersive, difficile, ou très personnelle.`;
        const familyWarning = contextImpact; // compatibilité avec le template

        // ── Traduire blendedGenreIds en noms lisibles pour le prompt ──
        const blendedIds = (preferences.blendedGenreIds || '').split(',').map(Number).filter(Boolean);
        const blendedNames = blendedIds.map(id => GENRE_ID_NAMES[id] || id).join(', ');
        // A2-fix : l'ancien check (blendedGenreIds.includes(10749)) était toujours vrai car blendedGenreIds
        // contient toujours les genres du mood. Le vrai signal = est-ce que les films de référence eux-mêmes
        // sont romantiques ? Si mood inclut romance MAIS films de référence ne le sont pas → warning.
        const adnHasRomance = (likedMovies || []).some(m => (m.genre_ids || []).includes(10749));
        const adnIsBiopic = (likedMovies || []).some(m => (m.genre_ids || []).includes(36) || (m.genre_ids || []).includes(18) && !(m.genre_ids || []).includes(10749));
        const romanceWarning = !adnHasRomance && preferences.mood?.includes('10749')
            ? `\n⛔ ROMANCE NON CONFIRMÉE PAR L'ADN : Le mood inclut la Romance/Émotion mais les films de référence ne sont PAS des films romantiques. Cherche des films émouvants dans le registre des références — PAS des romances sentimentales pures. Score = 0 pour tout film dont le genre DOMINANT est Romance sans dimension de dépassement humain, biopic, ou humour.`
            : '';

        // ── Détection polarité émotionnelle selon les références ──
        // Quand mood = émouvant + références romantiques : cibler romance chaleureuse, PAS drame émotionnel
        const sadExcluded = (preferences.exclude || []).includes('sad');
        const isRomanticMood = preferences.mood === '18,10749';
        const hasReferences = preferences.lastLovedMovies?.length > 0;
        const isCouple = preferences.context === 'couple';

        // POLARITÉ A active si :
        //   • des références romantiques sont fournies + sad exclu (ADN-driven)
        //   • OU pas de références + contexte couple + sad exclu (fallback romance par défaut)
        const defaultsToRomance = (adnHasRomance && sadExcluded) || (!hasReferences && isCouple && sadExcluded);

        const refLabel = hasReferences ? ` (références : ${(likedMovies||[]).map(m=>m.title).join(', ')})` : ' (aucune référence → défaut romance chaleureuse)';

        const inspiringBiopicWarning = isRomanticMood
            ? defaultsToRomance
                // POLARITÉ A : romance chaleureuse ciblée
                ? `\n💕 POLARITÉ DÉTECTÉE : ROMANCE CHALEUREUSE / FEEL-GOOD${refLabel}
→ L'utilisateur veut une romance POSITIVE, RÉCONFORTANTE, CHALEUREUSE. Pas un drame.
→ FILMS CIBLES PARFAITS : "Crazy Stupid Love", "The Holiday", "Notting Hill", "Marry Me", "Ticket to Paradise", "Serendipity", "Julie & Julia", "Begin Again", "One Day (2023)", "Hitch", "About Time", "La La Land".
→ FILMS INTERDITS DANS CE CONTEXTE (Score = 0) :
  • Biopics / histoires vraies inspirantes SANS romance centrale : "À la recherche du bonheur", "Le Discours d'un roi", "Eddie the Eagle" → émouvants mais PAS des romances.
  • SF contemplative/intellectuelle sans romance centrale : "Premier Contact (Arrival)", "Interstellar", "Her" → beau mais pas "date movie chaleureux".
  • Drames émotion-maladie : "Mr. Church", "À deux mètres de toi", "Five Feet Apart", "The Fault in Our Stars".
  • Drames humains sans romance : films sur l'amitié, la perte, la mort sans dimension romantique principale.
  • Comédies familiales / feel-good sans romance : "Little Miss Sunshine", "Soul" → charmants mais pas des date movies.
→ RÈGLE D'OR : Le genre principal DOIT être Romance (10749). Un film "émouvant" sans romance centrale n'est PAS ce que l'utilisateur cherche ici. Il veut se blottir avec son partenaire devant une belle histoire d'amour — pas pleurer devant un drame, pas regarder un biopic.`
                // POLARITÉ B : références biopics/histoire vraie ou pas de contexte couple → dépassement humain
                : hasReferences
                    ? `\n🎯 MOOD "ÉMOUVANT / INSPIRANT" + FILMS DE RÉFÉRENCE : Ce mood couvre deux registres. L'ADN indique lequel : si références = biopics/histoires vraies (Rocky, Judy, Williams...) → favorise le dépassement humain, -45 pts pour les romances sentimentales pures. Si références = romances (The Notebook, Titanic) → les romances sont bienvenues.`
                    : ''
            : '';

        // ── Cast ADN : acteurs issus des films de référence ──
        const adnCastIds = preferences.adnCastIds || [];
        const adnCastNames = preferences.adnCastNames || [];
        const adnDirectors = preferences.adnDirectors || [];
        const castAdnNote = (adnCastIds.length > 0 || adnCastNames.length > 0)
            ? `\n\n🎭 ACTEURS & RÉALISATEURS DES FILMS DE RÉFÉRENCE :${
                adnCastNames.length > 0 ? `\n  Acteurs : ${adnCastNames.join(', ')}` : ''}${
                adnDirectors.length > 0 ? `\n  Réalisateurs : ${adnDirectors.join(', ')}` : ''}${
                adnCastIds.length > 0 ? `\n  (IDs TMDB : ${adnCastIds.join(', ')})` : ''}
  → Certains films du pool ont été trouvés spécifiquement parce qu'ils partagent des acteurs avec les films de référence de l'utilisateur.
  → Accorde un BONUS de +8 pts aux films qui font figurer un de ces acteurs (même si ce n'est pas le rôle principal).
  → L'utilisateur apprécie ces acteurs — c'est un signal fort de cohérence avec ses goûts.`
            : '';

        // ── Univers culturel : résonance identitaire (Self-congruity theory, Social Identity Theory) ──
        const culturalUniverse = preferences.cultural_universe || '';
        const culturalNote = culturalUniverse
            ? `\n\n🌍 UNIVERS CULTUREL DÉTECTÉ : "${culturalUniverse}"
  → PRINCIPE PSYCHOLOGIQUE : Les spectateurs cherchent à se voir représentés dans ce qu'ils regardent (Self-congruity theory, Tajfel & Turner 1979).
  → Accorde un BONUS de +12 pts aux films qui appartiennent clairement à cet univers culturel.
  → Si un film du pool est dans le même univers culturel (même communauté représentée, mêmes codes culturels, casting similaire), c'est LE signal le plus fort de pertinence.
  → Ne sacrifie pas la qualité narrative, mais à score égal, TOUJOURS préférer le film culturellement résonant.`
            : '';

        // Avertissement conflit ADN/mood (ex: légèreté + Get Out)
        const conflictWarning = preferences.adnConflictsWithMood
            ? `\n⚠️ CONFLIT ADN/MOOD DÉTECTÉ : Les films de référence appartiennent à un genre OPPOSÉ au mood choisi (ex: film d'horreur cité pour une soirée légère). Dans ce cas, le MOOD est prioritaire pour le genre — cherche des films du genre demandé (${blendedNames}) mais avec la SOPHISTICATION NARRATIVE et le niveau d'exigence du film de référence. Ne recommande PAS des films du genre du film de référence.`
            : '';

        const systemPrompt = `Tu es le moteur de recommandation cinéphile de CineaMatch IA. Tu appliques un scoring multicritères avec garantie de diversité.

⚠️ RÈGLE CRITIQUE — ADN CINÉPHILE :
Les films de référence (ADN) calibrent le style narratif, le rythme et l'esthétique visuelle.
L'ÉNERGIE/MOOD donne le registre émotionnel général. Les GENRES EFFECTIFS ci-dessous ont priorité sur le libellé du mood.
${romanceWarning}${inspiringBiopicWarning}${conflictWarning}${castAdnNote}${culturalNote}

═══════════════════════════════════════════
PROFIL SPECTATEUR
═══════════════════════════════════════════
👤 CONTEXTE : ${preferences.contextLabel}
⚡ ÉNERGIE / MOOD : ${preferences.moodLabel}${preferences._subMoodLabel ? `\n🎯 SOUS-MOOD PRÉCIS : "${preferences._subMoodLabel}" — l'utilisateur a précisé qu'il veut spécifiquement ce registre. Priorise les films qui correspondent exactement à ce sous-mood.` : ''}
🎭 GENRES EFFECTIFS (blend ADN + mood) : ${blendedNames || preferences.moodLabel}
🧠 NIVEAU D'ATTENTION : ${preferences.pace === 'easy' ? 'Détendu (simplicité avant tout)' : preferences.pace === 'complex' ? 'Attentif (scénario construit)' : preferences.pace === 'mindblow' ? 'Mind-blow (complexité max)' : 'Peu importe'}
⏱️ DURÉE DISPONIBLE : ${durationLabel}
🌍 LANGUE / ORIGINE : ${(l => l && l !== 'any' ? (LANG_LABELS[l] || l) : 'Peu importe')(preferences.detectedLanguage || preferences.language)}
🎬 ADN STYLE CINÉPHILE : ${user_dna || 'Non fourni'}
🚫 EXCLUSIONS : ${preferences.excludeLabels || 'Aucune'}
📅 ÉPOQUE : ${eraLabel}
${rerollContext}${familyWarning}${ageContext}${duoContext}${userPersonalization}${streamingContext}${recoPrefsContext}

⚠️ IMPORTANT: Ces films candidats ont DÉJÀ été pré-filtrés pour correspondre à la demande. Si l'utilisateur mentionne un acteur, TOUS ces films le contiennent (même si ce n'est pas précisé dans le synopsis court). Ne pénalise pas un film pour ça.
${(preferences.language && preferences.language !== 'any') ? `⛔ RÈGLE LANGUE ABSOLUE : L'utilisateur a choisi "${({fr:'Films français',en:'Films américains/anglais',ko:'Films asiatiques',es:'Films hispaniques'}[preferences.language] || preferences.language)}". Si un film candidat n'est PAS dans cette langue originale, attribue-lui un score de 0 et ne le sélectionne JAMAIS dans ton top 3.` : ''}

═══════════════════════════════════════════
SYSTÈME DE SCORING DYNAMIQUE (100 pts)
═══════════════════════════════════════════
${weightingDescription}

📐 CALCUL DÉTAILLÉ PAR FILM :

🧬 ÉTAPE A — ADN STYLE (${weights.dna} pts MAX — CRITÈRE DOMINANT)
→ Films de référence : ${user_dna || 'non fourni'}.
→ Le film partage-t-il le même STYLE narratif ? (rythme, mise en scène, esthétique, niveau d'exigence)
→ ⚠️ NE PAS évaluer la similarité de GENRE — seulement le style et la qualité narrative.
→ ${weights.dna} pts = style très proche | ${Math.round(weights.dna*0.5)} pts = vague ressemblance | 0 pt = aucun lien.

🎯 ÉTAPE B — PERTINENCE THÉMATIQUE (${weights.theme} pts max)
→ Bonus secondaire si le film correspond à un thème implicite du profil (hors genre).

⚡ ÉTAPE C — ADÉQUATION MOOD/ÉNERGIE (${weights.mood} pts max)
→ Énergie demandée : ${preferences.moodLabel}.
→ Le film correspond-il au rythme, au ton, à l'intensité émotionnelle attendus ?
→ Attention au niveau d'attention : ${preferences.pace === 'easy' ? 'évite les films denses et cryptiques' : preferences.pace === 'mindblow' ? 'favorise les films à multiples couches' : 'Scénario construit OK'}.
${preferences.mood === '18,10749' ? `→ MOOD "ÉMOUVANT / INSPIRANT" — Ce mood couvre DEUX polarités distinctes selon les références fournies :

  🌟 POLARITÉ A — Émotion POSITIVE/RÉCONFORTANTE (About Time, La La Land, Her, Amelie, Soul, Eternal Sunshine) :
  → Chaleur émotionnelle, nostalgie douce, amour adulte, humour et émotion mêlés, fin heureuse ou apaisante.
  → Films cibles : "Crazy Stupid Love", "Marry Me", "The Holiday", "Notting Hill", "Julie & Julia", "Midnight in Paris", "Chef", "Begin Again".
  → À ÉVITER si ces références : mélodrames lourds, romances tragiques, deuil comme intrigue principale.

  💧 POLARITÉ B — Émotion INSPIRANTE/DÉPASSEMENT (Rocky, Whiplash, À la recherche du bonheur) :
  → Résilience, ambition, biopic, histoire vraie, dépassement de soi.
  → Films cibles : "La Méthode Williams", "Eddie the Eagle", "Judy", "Bohemian Rhapsody", "The Pursuit of Happyness".

  ⚠️ RÈGLE : Identifie la polarité depuis les références fournies et score en conséquence.
  Si les références sont romantiques/poétiques (La La Land, About Time, Her) → POLARITÉ A : donne ${weights.mood} pts aux films chauds/romantiques/réconfortants. Score = 0 pour les mélodrames pleurants (Nicholas Sparks, sick-lit).
  Si les références sont des biopics/histoires vraies → POLARITÉ B.` : ''}

⭐ ÉTAPE D — QUALITÉ OBJECTIVE (${weights.quality} pts max)
→ ≥ 8.0 = ${weights.quality} pts | 7.5-8.0 = ${Math.round(weights.quality*0.8)} pts | 7.0-7.5 = ${Math.round(weights.quality*0.6)} pts | < 7.0 = ${Math.round(weights.quality*0.4)} pts.

⛔ PÉNALITÉS (soustraire du total)

— EXCLUSIONS & CONTENU —
→ ID dans [${excludedIds.join(', ')}] : Score = 0 FORCÉ
→ Genre explicitement exclu (animation, horreur, tristesse…) : Score = 0 FORCÉ
${preferences.context === 'family' ? '→ Contenu adulte/violent/sexuel avec contexte famille : Score = 0 FORCÉ' : ''}
${preferences.exclude?.includes('horror') ? '→ Film d\'horreur (genre 27 : gore, jump-scares, créatures, possession) alors que l\'utilisateur l\'a explicitement exclu : Score = 0 FORCÉ.' : ''}
${preferences.exclude?.includes('scary') ? '→ Film d\'horreur pure (Conjuring, Hereditary, Insidious, Annabelle, Sinister...) alors que l\'utilisateur a exclu "qui fait peur" : Score = 0 FORCÉ.\n→ Thriller de suspense intense (Se7en, Silence des Agneaux, Prisoners) : -20 pts — acceptable si c\'est le meilleur match, mais à éviter si des alternatives existent.\n→ Note : un thriller d\'action ou dystopique (American Nightmare, Jason Bourne, Mission Impossible) N\'EST PAS "qui fait peur" — ne pas pénaliser.' : ''}
${preferences.exclude?.includes('sad') ? `→ Film déprimant/lourd/à fin tragique alors que l'utilisateur l'a exclu : Score = 0 FORCÉ.
→ ARCHÉTYPES INTERDITS avec exclusion "trop triste" :
  • Romances-tragédie / Nicholas Sparks style : "Une seconde chance (The Best of Me)", "N'oublie jamais (The Notebook)", "Là où tu es (Message in a Bottle)", "Chère John", "The Longest Ride" → Score = 0.
  • Sick-lit / romance maladie : "À deux mètres de toi (Five Feet Apart)", "Nos étoiles contraires (The Fault in Our Stars)", "Avant toi (Me Before You)", "Everything, Everything", "À deux c'est mieux" → Score = 0.
  • Drames de deuil, séparation, perte d'un être cher comme intrigue principale → Score = 0.
  • POLARITÉ ÉMOTIONNELLE : "émouvant" ne signifie PAS "douloureux". L'utilisateur veut de l'émotion POSITIVE, de la chaleur, du réconfort — pas des larmes de tristesse. Films cibles : "About Time", "La La Land", "Soul", "Toy Story 3", "Crazy Stupid Love", "Marry Me", non pas des mélodrames déchirants.` : ''}
${preferences.exclude?.includes('adult') ? '→ Film avec nudité/contenu sexuel explicite alors que l\'utilisateur l\'a exclu : Score = 0 FORCÉ.' : ''}
${preferences.exclude?.includes('animation') ? '→ Film d\'animation alors que l\'utilisateur l\'a exclu : Score = 0 FORCÉ.' : ''}
${preferences.exclude?.includes('teen') ? `→ Film dont le public cible est clairement adolescent (lycée, coming-of-age, romance ado, teen drama) alors que l'utilisateur l'a exclu : Score = 0 FORCÉ.
→ Critères d'exclusion : personnages principaux ≤ 18 ans, intrigue centrée sur l'adolescence, public visé 13-17 ans, romance lycéenne/collégienne.
→ LISTE D'EXEMPLES INTERDITS (Score = 0) :
  • Romances ado : "À tous les garçons que j'ai aimés", "The Kissing Booth", "Twilight", "Bande de filles", "Mes premiers pas"
  • Sick-lit ado : "À deux mètres de toi (Five Feet Apart)", "Nos étoiles contraires", "Everything, Everything", "Avant toi" (protagoniste pas ado mais vibe similaire)
  • Coming-of-age : "Divergente", "The Maze Runner", "Hunger Games", "The Breakfast Club", "Juno", "Lady Bird"
  • Dramas lycée : "13 Reasons Why", "Euphoria", "Sex Education", "Skins"
→ ATTENTION : un film avec de jeunes adultes (20-25 ans) n'est PAS forcément "teen". Critère clé = est-ce que le lycée/l'adolescence est le CADRE CENTRAL de l'histoire ?` : ''}
${preferences.exclude?.includes('slow') ? '→ Film au rythme contemplatif/très lent avec exclusion "lenteur" demandée : -30 pts. Privilégie un rythme soutenu, des scènes qui avancent.' : ''}
${preferences.exclude?.includes('complex') ? '→ Film à scénario alambiqué/cryptique/non-linéaire difficile à suivre alors que l\'utilisateur veut du simple : -30 pts. Favorise des récits clairs et accessibles.' : ''}

— DURÉE (contrainte ferme) —
${preferences.duration === 'short' ? '→ Film > 2h (120 min) alors que durée demandée = court (< 1h45) : -35 pts. C\'est une contrainte forte — pénalise sévèrement.' : preferences.duration === 'long' ? '→ Film < 1h45 (105 min) alors que durée demandée = long format (> 2h) : -25 pts.' : ''}

— GENRE REQUIS —
→ Le film n'appartient PAS au genre demandé (${preferences.moodLabel}) — ex: documentaire pour "thriller", comédie pour "suspense" : -45 pts. C'est la contrainte principale.
→ Si le film est uniquement un documentaire ou un film de musique sans aucune dimension thriller/action/drama selon le mood demandé : Score = 0 FORCÉ.

— ÉPOQUE —
${preferences.era === 'new' ? `→ Film sorti AVANT 2020 alors que l'utilisateur veut des films récents (+2020) : Score = 0 FORCÉ. C'est une contrainte non-négociable.` : `→ Hors époque "${eraLabel}" : -40 pts.`}

— NIVEAU D'ATTENTION —
${preferences.pace === 'easy' ? '→ Film dense/cryptique/confus avec pace=détendu : -20 pts. Favorise la clarté narrative et le divertissement accessible.' : ''}
${preferences.pace === 'mindblow' ? '→ Film prévisible/simple avec pace=mind-blow : -15 pts. Exige des retournements, plusieurs couches narratives, une intrigue qui résiste.' : ''}

— CONTEXTE SOCIAL —
${preferences.context === 'couple' ? '→ Film trop solitaire/contemplatif sans dimension relationnelle pour un visionnage en couple : -12 pts. Bonus +10 pts si le film crée un "effet miroir" ou invite à la discussion post-visionnage.' : ''}
${preferences.context === 'friends' ? '→ Film trop intimiste/personnel/lent pour une soirée entre amis : -15 pts. Favorise les films avec énergie, humour ou suspense partageable en groupe.' : ''}
${preferences.context === 'alone' ? '→ Pas de contrainte de contexte — l\'expérience peut être immersive, difficile ou très personnelle. Bonus +5 pts pour les films qui gagnent à être vus seul.' : ''}

═══════════════════════════════════════════
GARANTIE DE DIVERSITÉ (CRITIQUE)
═══════════════════════════════════════════
Dans ton classement final, les 3 premiers films DOIVENT être diversifiés :
→ Pas 3 thrillers si des alternatives existent. Pas 3 films de la même décennie si évitable.
→ Si le top 2 est du même sous-genre, le 3ème DOIT être d'un registre différent.
→ Objectif : 3 films qui se COMPLÈTENT (ex: un intime, un épique, un original) plutôt que 3 clones.
⚠️ RÈGLE PLANCHER DE QUALITÉ : La diversité ne doit JAMAIS sacrifier la qualité.
→ Si le candidat "diversité" a un score < 72 pts, ne l'impose PAS — prends plutôt le prochain film bien noté même s'il est similaire.
→ Un film à 80 pts légèrement similaire vaut mieux qu'un film à 60 pts "différent".

═══════════════════════════════════════════
MATCH REASONS — RÈGLES DE RÉDACTION
═══════════════════════════════════════════
${dnaAnchor}

Chaque match_reason doit :
1. Être rédigée en ${lang === 'en' ? 'ANGLAIS' : 'FRANÇAIS'}, 1-2 phrases percutantes (max 180 caractères).
2. Mentionner CE QUI EST SPÉCIFIQUE à ce film (une scène emblématique, un thème unique, un style distinctif).
3. Faire le PONT avec le profil : relier explicitement au mood, à l'envie, ou à un film aimé.
4. VARIER le style d'accroche : parfois factuel, parfois émotionnel, parfois surprenant.
5. Ne jamais être générique (interdit : "un film parfait pour toi", "correspond à tes goûts").

Exemples de bons débuts : "Dans la lignée de [film aimé]...", "Si tu cherches [envie], ce film...", "L'atmosphère [adj] de [titre] va...", "Rarement un film [caractéristique unique]..."

═══════════════════════════════════════════
FORMAT JSON OBLIGATOIRE
═══════════════════════════════════════════
Retourne TOUS les films scorés. JSON strict, aucun texte autour :
{"recommendations": [{"tmdb_id": number, "match_score": number, "match_reason": "string", "diversity_tag": "string"}]}

où diversity_tag est un mot décrivant le registre du film (ex: "épique", "intime", "haletant", "dépaysant", "poétique", "viscéral").`;

        const userPrompt = `Voici les ${candidates.length} films candidats à scorer :

${enrichedCandidates}

Applique le scoring dynamique, garantis la diversité du top 3, et génère des match reasons percutantes.`;

        try {
            const resp = await fetch(OPENAI_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${this._resolveKey()}`
                },
                signal: controller.signal,
                body: JSON.stringify({
                    model: "gpt-4o-mini",
                    messages: [
                        { role: "system", content: systemPrompt },
                        { role: "user", content: userPrompt }
                    ],
                    temperature: 0.25,  // Légèrement plus haut pour varier les formulations des reasons
                    response_format: { type: "json_object" },
                    max_tokens: 4000   // Plus de tokens pour des reasons plus riches
                })
            });
            clearTimeout(timeout);

            if (!resp.ok) throw new Error(`OpenAI HTTP ${resp.status}`);
            const data = await resp.json();
            const parsed = JSON.parse(data.choices[0].message.content);
            let recommendations = parsed.recommendations || [];

            // ── POST-PROCESSING : Garantie diversité top 3 côté client ──
            const sorted = [...recommendations].sort((a, b) => b.match_score - a.match_score);
            const diversified = this._applyDiversityFilter(sorted, candidates);

            // Log debug
            console.log(`🎬 Scoring IA : ${recommendations.length} films scorés`);
            console.log(`⚖️ ADN x${weights.dna}% | Mood x${weights.mood}% | Qualité x${weights.quality}% | Thème x${weights.theme}%`);
            diversified.slice(0, 3).forEach((r, i) =>
                console.log(`  ${i+1}. [${r.match_score}pts | ${r.diversity_tag || ''}] ID:${r.tmdb_id} — ${r.match_reason?.substring(0, 90)}...`)
            );

            return diversified;
        } catch (error) {
            clearTimeout(timeout);
            // Point 8 : message spécifique si timeout (AbortError) vs autre erreur
            if (error.name === 'AbortError') {
                console.warn('⏱️ OpenAI timeout (30s) — scoring abandonné');
                throw new Error(lang === 'en'
                    ? 'AI took too long to respond — please try again'
                    : "L'IA a mis trop de temps à répondre — réessaie dans un instant");
            }
            console.error("OpenAI Hybrid Ranking Error:", error);
            throw new Error("Rank API failed: " + error.message);
        }
    },

    // ─────────────────────────────────────────────────────────────
    //  GÉNÈRE des raisons personnalisées pour les films sans match_reason
    //  Un seul appel IA pour tous les films concernés (max 3)
    // ─────────────────────────────────────────────────────────────
    async generateMissingReasons(movies, userProfile, lang = 'fr') {
        if (!this._resolveKey()) return;
        const targets = movies.filter(m => !m.match_reason);
        if (!targets.length) return;

        const isFr = lang !== 'en';
        const mood = userProfile?.moodLabel || userProfile?.mood || '';
        const context = userProfile?.contextLabel || userProfile?.context || '';
        const lovedMovies = (userProfile?.lastLovedMovies || [])
            .map(m => m?.title || (typeof m === 'string' ? m : '')).filter(Boolean).slice(0, 3).join(', ');

        const filmList = targets.map((m, i) => {
            const genres = (m.genres || []).map(g => g.name).filter(Boolean).join(', ');
            const director = m.credits?.crew?.find(p => p.job === 'Director')?.name || '';
            const cast = m.credits?.cast?.slice(0, 3).map(a => a.name).join(', ') || '';
            const score = m.vote_average?.toFixed(1) || '?';
            const year = m.release_date?.split('-')[0] || '?';
            const overview = m.overview?.slice(0, 200) || '';
            return `Film ${i+1}: "${m.title}" (${year}) | Genres: ${genres} | Réalisateur: ${director} | Cast: ${cast} | Note: ${score}/10\nSynopsis: ${overview}`;
        }).join('\n\n');

        const prompt = isFr
            ? `Tu es un critique de cinéma expert. Un utilisateur cherche ${mood ? `un film pour "${mood}"` : 'un film'} ${context ? `dans le contexte "${context}"` : ''}${lovedMovies ? `. Ses films de référence : ${lovedMovies}` : ''}.

Pour chaque film ci-dessous, génère une raison personnalisée de 2 phrases max (max 200 caractères) expliquant POURQUOI ce film spécifique correspond à ce profil. Sois précis, mentionne des éléments concrets du film (réalisateur, atmosphère, thème unique). Ne sois jamais générique.

${filmList}

Réponds en JSON strict : {"reasons": ["raison film 1", "raison film 2", ...]}`
            : `You are an expert film critic. A user is looking for ${mood ? `a film for "${mood}"` : 'a film'} ${context ? `in the context "${context}"` : ''}${lovedMovies ? `. Their reference films: ${lovedMovies}` : ''}.

For each film below, generate a personalized 2-sentence reason (max 200 chars) explaining WHY this specific film matches this profile. Be precise, mention concrete elements (director, atmosphere, unique theme). Never be generic.

${filmList}

Reply in strict JSON: {"reasons": ["reason film 1", "reason film 2", ...]}`;

        try {
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 12000);
            const resp = await fetch(OPENAI_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${this._resolveKey()}` },
                signal: controller.signal,
                body: JSON.stringify({
                    model: 'gpt-4o-mini',
                    messages: [{ role: 'user', content: prompt }],
                    temperature: 0.4,
                    response_format: { type: 'json_object' },
                    max_tokens: 600
                })
            });
            clearTimeout(timeout);
            if (!resp.ok) return;
            const data = await resp.json();
            const parsed = JSON.parse(data.choices[0].message.content);
            const reasons = parsed.reasons || [];
            targets.forEach((m, i) => {
                if (reasons[i]) m.match_reason = reasons[i];
            });
        } catch(e) {
            console.warn('generateMissingReasons failed (non-bloquant):', e.message);
        }
    },

    // ─────────────────────────────────────────────────────────────
    //  DIVERSITÉ FILTER : Garantit que le top 3 est varié
    //  Si les 3 premiers ont le même "diversity_tag" ou les mêmes
    //  genres principaux, on intercale le meilleur film d'un autre registre.
    // ─────────────────────────────────────────────────────────────
    _applyDiversityFilter(sortedRecs, candidates) {
        if (sortedRecs.length <= 3) return sortedRecs;

        const result = [sortedRecs[0]]; // Le #1 est toujours gardé
        const usedTags = new Set([sortedRecs[0].diversity_tag || 'unknown']);
        const usedGenreSigs = new Set();

        // Calcule la "signature genre" d'un film (2 genres principaux)
        const getGenreSig = (rec) => {
            const movie = candidates.find(c => Number(c.id) === Number(rec.tmdb_id));
            if (!movie || !movie.genre_ids) return 'unknown';
            return movie.genre_ids.slice(0, 2).sort().join('-');
        };
        usedGenreSigs.add(getGenreSig(sortedRecs[0]));

        // Slot #2 : meilleur score parmi les restants
        for (let i = 1; i < sortedRecs.length && result.length < 2; i++) {
            result.push(sortedRecs[i]);
            usedTags.add(sortedRecs[i].diversity_tag || 'unknown');
            usedGenreSigs.add(getGenreSig(sortedRecs[i]));
        }

        // Slot #3 : préfère un film d'un tag ET genre-sig différents
        const remaining = sortedRecs.filter(r => !result.includes(r));
        const diverse = remaining.find(r => {
            const tag = r.diversity_tag || 'unknown';
            const sig = getGenreSig(r);
            return !usedTags.has(tag) || !usedGenreSigs.has(sig);
        });

        if (diverse) {
            result.push(diverse);
            console.log(`🌈 Diversité : #3 remplacé par "${diverse.diversity_tag}" (ID:${diverse.tmdb_id}) pour la variété`);
        } else {
            // Pas d'alternative assez diverse, on prend juste le suivant
            const fallback = remaining.find(r => !result.includes(r));
            if (fallback) result.push(fallback);
        }

        // Réintègre le reste après le top 3 diversifié
        const tail = sortedRecs.filter(r => !result.includes(r));
        return [...result, ...tail];
    }
};
